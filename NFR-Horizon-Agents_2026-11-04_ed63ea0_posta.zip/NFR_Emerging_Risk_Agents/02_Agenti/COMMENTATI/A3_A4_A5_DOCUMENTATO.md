# A3, A4, A5, A6, A7, A8 — perche' di ogni blocco

Documentazione dei prompt generati da `02_Agenti/modelli/A3.md`, `A4.md`,
`A5.md`, `A6.md`. Numeri di passo, sezioni e controlli sono quelli dei modelli; il
collaudo (`verifica_riferimenti.py`) controlla che coincidano.

# A3 Interim Update (settimanale)

## Input
"Utilizza **sempre** lo strumento di ricerca file o altri strumenti di ricerca aziendale per accedere ai file della knowledge." (dal 13/10, la stessa frase in A1, A3, A4, A7 e A8; prima "Usa sempre la
ricerca nei file o quella aziendale: non rispondere a memoria"): obbliga a leggere davvero
`News_Inbox` e `Analisi_Interne`. Senza, su un
compito che sembra chiaro il planner puo' saltare il recupero.

"Baseline: SOLO l'allegato Input_A3_A4.txt della chat, mai dalla knowledge" (dal 23/10, AU7, D-83; lo stesso in A4
con `Input_A3_A4.txt`): fino ad allora la baseline era il file singolo `Kernel/Baseline_corrente.txt` nella knowledge,
da ricopiare a mano a ogni ciclo e indicizzato con ritardo. Il 13/10 A3 ha risposto "Baseline mancante" su un file
appena caricato, e una copia dimenticata sarebbe stata letta vecchia senza avvisi. L'allegato lo scrive il comando
`baseline` insieme a quello di A1; senza allegato A3 risponde "Baseline mancante" (A4 lo dice in testa al parere),
quindi il prompt schedulato del lunedi', che non porta allegati, non si usa piu'.

## Ruolo
"Non modifichi score e non proponi numeri": principio 3 del sistema. Senza,
il registro deriverebbe dietro il ciclo delle notizie e smetterebbe di misurare
il rischio.

## Procedura

### Passo 1 — Settimana = lunedi'
Il foglio raggruppa le notizie per lunedi' (formula `Settimana` di NewsLog) e
la scrittura rifiuta una settimana che non e' un lunedi': i due devono parlare
la stessa lingua.

### Passo 2 — Tre canali, deduplica per fatto, codice fonte
I tre canali (raccolta automatica dei feed e file manuali in `News_Inbox`,
siti configurati, documenti interni) coprono cose diverse: i feed danno
regolarita', i siti le autorita' senza feed, i documenti interni la
prossimita' vera. L'elenco delle fonti e' nelle istruzioni (segnaposto
`{{FONTI}}`, da `01_Kernel/fonti.md`) e non in una knowledge: cio' che e'
recuperabile e' ignorabile.

Regola "la copertura mediatica non e' evidenza": dieci articoli sullo stesso
fatto sono un segnale, non dieci. Senza deduplica la soglia di 3 segnali
netti si supererebbe con una sola notizia molto ripresa.

`codice_fonte` rende la regola "solo fonti dell'elenco" verificabile: lo
schema ne impone il formato, la scrittura settimanale ferma un codice che non
e' nell'elenco o e' escluso. `MAN` lascia entrare cio' che un analista ha
scelto di caricare, ma lo rende visibile in NewsLog (colonna Codice_Fonte).

### Passo 3 — id_notizia
Formato fisso: la scrittura deduplica per id, quindi rilanciare la stessa
settimana non duplica le righe.

### Passo 4 — Nove intensita', sempre
Ogni notizia e' valutata su tutte le categorie, non solo sulla piu' ovvia: e'
cosi' che emergono le aree non presidiate (una notizia su una categoria senza
rischi censiti). Esattamente nove voci, una per categoria della tassonomia
interna (D-74; fino al 07/10 sette, gli event type di Basilea): la scrittura lo
verifica.

### Passo 5 — Rischio collegato o null
Null e' un'informazione, non un errore: alimenta "Notizie non collegate" e il
presidio per categoria nel foglio Notizie.

Dal registro unico (D-79) i rischi in osservazione sono rischi come gli altri: una
notizia su uno di loro va in `rischio_collegato` (passo 5) e, se realizza il suo segnale
di avvicinamento, A3 propone un flag (passo 6). Notizie e flag arrivano ad A1 nella
baseline del ciclo dopo (`notizie_a3`, `flag_a3` del rischio), come evidenza da
verificare: lo stato lo cambia solo la regola, con i valori di A1 validati.

### Passo 6 — Flag proposti
Un flag cita un descrittore della rubrica: e' un argomento per il prossimo
ciclo, non una variazione. I segnali netti del Registro (conteggio delle
notizie peggiorative meno migliorative) restano deterministici e indipendenti
dal flag.

Passo 6-bis (D-75): la proposta di ciclo straordinario, solo con la regola del
segnale critico della rubrica (sezione 6). Una regola esplicita evita due errori
opposti: proporlo a ogni notizia forte (la funzione di rischio smetterebbe di
leggerlo) o mai. Decide la funzione di rischio; lo script la mette a video e nel
foglio Notizie. Per stare negli 8.000 caratteri il prompt e' stato accorciato senza
togliere regole (7.914).

### Passo 7 — Sintesi
Le aree non presidiate sono dette esplicitamente perche' sono il segnale piu'
utile di A3 per il ciclo successivo (catena verificata in `run_catena.py`).

### Passo 8 — Autocontrollo
I quattro valori letterali: il foglio conta per testo esatto, un sinonimo vale
zero in silenzio.

# A4 News Assessor (su richiesta)

## Regole
- "Mai una cifra nuova": un numero in un parere viene citato come se fosse una
  valutazione. Gli score vigenti si possono citare, dicendo che sono deliberati.
- "Mai una persona nominata": il parere circola in Teams; i nomi nelle notizie
  non aggiungono informazione sul rischio della Banca.
- Notizie: il foglio aggrega le notizie scritte da A3; A4 non scrive nulla.
- Parere "approfondito e motivato" (D-88, 29/10): il fatto in quattro-sei frasi, una o due frasi per ogni categoria
  (anche per quelle non toccate), l'anello del meccanismo per ogni rischio toccato, un paragrafo sulla coerenza con la
  baseline, il perche' di ogni verifica suggerita. Richiesta dell'utente: "il news assessor potrebbe essere un po'
  piu' prolisso". Nessuna lunghezza contata dallo script: il parere resta in chat.
  Promettere che la notizia compaia li' sarebbe falso.

## Struttura della risposta

### Sezione 1 — Il fatto
Separare il fatto dall'interpretazione e' la prima difesa contro la deriva
mediatica.

### Sezione 2 — Nove categorie
Stessa regola di A3: analisi di impatto su tutte e nove le categorie della
tassonomia interna (D-74), per trovare le aree non presidiate.

### Sezione 3 — Rischi toccati
Ancora il parere alla valutazione deliberata (la baseline), non a un giudizio
da zero.

### Sezione 4 — Coerenza
"Un solo segnale non e' una tendenza": la soglia di direzione in parole.

### Sezione 5 — Cosa suggerisco
Verifiche, non variazioni: la via per cambiare uno score e' il ciclo
trimestrale. Dal 07/10 (D-75), se la notizia soddisfa la regola del segnale
critico, A4 scrive in testa "PROPOSTA DI CICLO STRAORDINARIO" con i rischi e il
motivo: la stessa regola di A3, perche' una notizia portata a mano ad A4 puo'
essere proprio quella critica.

### Sezione 6 — Limiti
Un parere senza limiti dichiarati viene letto come piu' solido di quanto sia.

# A5 Challenger (trimestrale, dopo A1)

## Input ristretto
A5 riceve solo l'output di A1 e la baseline, mai le notizie: giudica se la
valutazione e' sostenuta da cio' che essa stessa cita. Se leggesse le stesse
fonti di A1 tenderebbe a rifare la valutazione invece di controllarla. In
Agent Builder: nessuna knowledge source. Per lo stesso motivo A5 **non** ha la
frase "Usa sempre lo strumento di ricerca file", che hanno A1, A3 e A4: le due
istruzioni sono in conflitto per scelta, non per svista.

## I controlli (C1-C10)
Ogni controllo ha una controparte in `07_Senza_Studio/controlli_a5.py` nella
misura in cui e' esprimibile come regola (vedi `04_Riferimenti/controlli_e_model_risk.md`, tabella dei
controlli). Il 30/09/2026 (D-49...D-56) i controlli sono stati ridotti a cio'
che A1 scrive davvero: stessa numerazione, contenuto piu' snello.

Dal 02/10 (D-69) il testo dei nove controlli non sta piu' nel modello di A5 ma
in `01_Kernel/controlli_A5.md`, e `componi_prompt.py` lo inserisce al posto di
`{{CONTROLLI}}`: lo stesso testo entra nell'allegato di A1
(`Input_A1_<ciclo>.txt`), che verifica il proprio output con le stesse regole
prima di rispondere. Il prompt composto di A5 e' identico a prima, salvo la
frase nuova di C8. A5 non perde indipendenza: non vede la knowledge ne' la
chat di A1, e giudica cio' che A1 consegna. Gli errori meccanici gli arrivano
piu' di rado, perche' il precontrollo dello script, quando lo si usa, li ferma prima.

### C1 — Completezza
Un rischio mancante, scritto a meta', sul radar si legge come un crollo. Un
rischio esistente non cambia categoria (D-74: salvo la riclassificazione di un
codice di Basilea, che e' un'Osservazione): se il meccanismo di perdita e' un
altro, e' un rischio nuovo con un id nuovo. Fino al 29/09 C1 guardava anche
l'esito, che ora calcola lo script (D-51).
Dal 04/11/2026 la parte meccanizzata di C1 guarda anche, come Osservazioni e
fuori dal testo del controllo (il prompt di A5 e' al limite): la parte
COLLEGATI: del rischio primario (D-97: id che esistono, non il rischio stesso,
non dichiarata dai due lati) e i temi da verificare della baseline (D-98: un
tema senza risposta e' un'Osservazione sul ciclo).

### C2 — Variazioni
Una voce per ogni valore cambiato, e solo per quelli: nessuna variazione
nascosta dietro una conferma. Il confronto "da/a" non c'e' piu' perche' i due
valori li aggiunge lo script dalla baseline; resta il controllo che ogni
cambio abbia la sua evidenza, compreso il passaggio di una Velocity da un
valore a non valutata.
Dal 04/11/2026 (D-96) una parte QUINDI: ripresa dal ciclo prima mentre un
valore cambia e' un'Osservazione: il "so what" puo' valere ancora, ma va
riletto.

### C3 — Evidenza delle variazioni
Data nella finestra del ciclo, evidenza specifica, massimo un punto: le regole
di variazione 2 e 3. Una Velocity prima non valutata entra con qualunque
valore.

### C4 — Plausibilita'
L'unico controllo senza controparte deterministica: dire se un 4 corrisponde
al descrittore 4 e' giudizio. E' il motivo per cui lo script si ferma se manca
l'esito di A5. Guarda anche: un rischio = un meccanismo di perdita (D-55); la
Velocity valorizzata solo se le fonti documentano i tempi (D-50); i numeri del
razionale (D-36: un numero senza fonte, non dichiarato come valutazione, e'
un'Osservazione). Niente piu' Gap_Controlli e pavimento D-47: il 29/09 fermavano
7 rischi su 7 su un dato che A1 non poteva vedere. La Prossimita 4-5 chiede un
caso nominato, ma dentro il descrittore (D-48). Dal 01/10 (D-65) "Probabilita
4-5 con la Banca esposta": un fenomeno diffuso non e' probabile per una Banca
che non ha il bersaglio; e' giudizio, quindi sta in C4 e non nello script.

### C5 — Fonti
Dal 30/09 sera (D-58) la Confidence del rischio non c'e' piu': ogni fonte ha
una rilevanza 1-3. C5 ferma una fonte datata dopo il ciclo e segnala come
Osservazione una Probabilita 5 o una Prossimita 4-5 senza una fonte di
rilevanza 3 (A5 giudica in C4 se la deroga per un fenomeno ad altissimo
impatto e' dichiarata e sostenibile) e le fonti perse con i valori invariati.
Prima la confidence misurava l'evidenza contando le fonti, e le fonti
dello stesso ente o sullo stesso fatto contano una volta.

### C6 — Deriva
Inflazione progressiva e deriva mediatica sono i due modi in cui il sistema
peggiora da solo. Il controllo meccanico guarda gli aumenti senza fonti nuove.

### C7 — Rilettura KRI
Solo KRI in vigore, ciascuno una volta. Un KRI in vigore non riletto non e' un
errore: A1 rilegge solo i valori che trova (D-53) e il foglio lo mostra come
"Non rilevato".

### C8 — Azioni
Sempre Osservazione dal 30/09 (D-54): l'euristica "sembra una persona" sbaglia
in entrambe le direzioni ("Immobili, Infrastrutture e Procurement" il 29/09).
La regola vera sta nella validazione: `valida` non accetta un owner che sembra
una persona, neanche "Accettato". Dal 02/10 (D-69) C8 guarda anche che
un'azione non ripeta un'azione aperta della baseline: nei dati di prova A1
riproponeva ogni trimestre le azioni gia' approvate. Lo script segnala la
stessa descrizione (a meno di maiuscole, spazi e punto finale) di un'azione
aperta dello stesso rischio; un'azione solo simile la giudica A5.

### C9 — KRI
Due per rischio, uno di Esposizione e uno di Evoluzione (D-64; prima da 1 a 3,
D-53); soglie entrambe o nessuna (D-53). "Uno per tipo" e le soglie invertite
non sono esprimibili in JSON Schema: C9 e la formula Stato del foglio sono i
presidi. Dal 03/11 (D-93) un KRI in vigore non riproposto resta in vigore (lo script lo riprende dalla
baseline); un KRI nuovo prende il posto di quello in vigore dello stesso tipo, e l'uscita del vecchio e' un'Osservazione;
anche un tipo diverso da quello della baseline e' un'Osservazione (un KRI non
cambia natura). Il prompt chiede ad A5 anche che i tipi siano "coerenti con
cio' che misurano": e' giudizio, lo script non lo controlla.

### C10 — Testi
Dal 29/10 (D-86): A1 scriveva testi troppo sintetici (descrizioni di una riga,
razionali di poche parole per parte). La guida di scrittura ha la tabella
"Lunghezze dei testi" (minimo e consigliato, in caratteri), che A5 riceve
nella parte 3 del suo allegato; lo stesso elenco e' `LUNGHEZZE` in
`controlli_a5.py` e il collaudo controlla che coincidano. Per A5 un testo
sotto il minimo e' un Bloccante (va corretto); lo script ne fa un rilievo per
rischio e lo porta in validazione come Osservazione: non ferma il ciclo. Il
precontrollo propone di farli allungare ad A1 nella stessa chat; chi lavora
puo' dire di no e proseguire. Un razionale senza le etichette (scritto prima
della D-68) si misura intero, contro la somma dei minimi delle sue parti.
Dal 03/11 (D-92) le righe dei rischi sono a una fascia intermedia (descrizione
350-600, ogni dimensione 150-250, azioni e KRI 150-300): con la fascia alta
l'output di A1 non stava nelle risposte di Copilot e il "continua" non
funzionava. Le righe dell'analisi dell'evento di A8 non cambiano.
Dal 04/11 (D-96, P14) la tabella ha una riga per la parte QUINDI: del razionale
(120-250): un razionale senza QUINDI e' un testo troppo corto, e il precontrollo
la fa aggiungere ad A1. La frase di C10 cita QUINDI (12 caratteri in piu' nel
prompt di A5).
Dal 03/11 (D-93, P17) C10 misura solo i testi scritti da A1: quelli di un
rischio esistente ripresi dalla baseline sono gia' validati. Per lo stesso
motivo C1 chiede descrizione e razionale solo a un rischio nuovo, e C2 chiede
(da motivare) di riscrivere la parte del razionale di un valore che cambia: se
resta quella della baseline motiva il valore di prima. Le righe dei controlli
lo dicono in poche parole (il prompt di A5 e' a 7.966 caratteri); la regola
intera e' nella guida di scrittura.

## Esito
"Da rivedere" se almeno un Bloccante. Dal 06/10 (D-71) A5 e' **facoltativo** e
nessun suo rilievo ferma il ciclo: lo script trasforma i suoi Bloccanti in
segnalazioni "Da motivare", che stanno sui rischi (colonna Rilievi), nella
colonna Segnalazioni del foglio Validazione e, contate, in Sintesi_Cicli e nel
Quadro; in validazione ogni rischio interessato chiede una Motivazione. Per
questo il ruolo nel prompt dice "I tuoi rilievi vanno al validatore: un
Bloccante lo obbliga a motivare la decisione" (prima: "Puoi arrestare il
ciclo"). Restano cancelli solo i difetti di integrita' dei controlli
meccanizzati (D-10). Fino al 05/10 (D-56) i Bloccanti di A5 fermavano il ciclo e
si superavano con `trimestrale --procedi-con-rilievi --motivo --decisore`.

# A6 Schede dei rischi (trimestrale, dopo la validazione)

Decisione D-40 (25/09): le schede di focus sui rischi sono un file a parte
rispetto al registro, e i loro testi lunghi li scrive un agente dedicato. Il
registro resta compatto (descrizione e razionale brevi di A1); la scheda
spiega a chi non conosce il tema.

## Lunghezze (D-88, 29/10)
descrizione_estesa 1000-2000 caratteri, spiegazione di ogni dimensione 400-800 (Velocity non valutata: una frase),
a_sostegno_di 100-300: piu' lunghe di quelle di A1 (D-86), perche' la scheda spiega a chi non conosce il tema. Le
stesse in `schede.LUNGHEZZE_A6` (il collaudo le confronta con le istruzioni). Un testo piu' corto non ferma le
schede: il comando `schede` le scrive e ne da' l'elenco ("Testi di A6 troppo corti: N"); l'app propone di darlo ad
A6 nella stessa chat e rilancia le schede con la risposta nuova. Lo schema di A6 ha i massimi alzati (2500 e 900).

## Ruolo
A6 non valuta: spiega una valutazione gia' validata. Per questo si lancia
DOPO il comando valida, e lo script rifiuta di preparargli l'input se il ciclo
ha ancora decisioni da prendere. Cosi' la scheda non puo' contraddire un
valore rettificato dal validatore.

## Input
Un solo allegato, `Input_A6_<ciclo>.json`, scritto dal comando
`schede-input` dal registro validato: per ogni rischio le quattro dimensioni
(Impatto, Probabilita, Prossimita, Velocity; la Velocity puo'
essere "non valutata"), gli anni di adeguamento, il presidio dei controlli
indicato dalla Banca, score,
urgenza (X, Y, Z, margine), livello di allerta con il motivo (D-63), variazioni
con l'evidenza, fonti, azioni, KRI con il tipo (D-64), storia degli score. Niente notizie, knowledge o ricerche: la scheda non deve
introdurre fatti che il ciclo non ha valutato. Dal 02/10 (D-68) lo script
divide il razionale di A1 nelle sue parti: `razionale_rischio` (il fenomeno) e
`motivazioni` (il perche' di ogni valore, con i documenti; null se A1 non ha
diviso il razionale); azioni e KRI arrivano con il loro razionale e
l'effetto atteso. Dividere nello script, non chiederlo ad A6, rende certo che
la motivazione di Impatto vada accanto all'Impatto.

## Regole
1. Una scheda per rischio, stesso id: controllato dallo script.
2. Valori immutabili: A6 non ne propone altri.
3. **Nessun numero nuovo**: ogni numero dei testi deve stare nei dati del
   rischio o nella rubrica. E' la controparte deterministica del divieto di
   inventare: `schede.controlla_a6` estrae i numeri (una data in italiano e in
   ISO sono gli stessi numeri; 4,2 = 4.2) e ferma le schede se uno non c'e'.
   Una stima dell'agente ("circa il 30%") non passa.
4. Descrizione estesa: il fenomeno in termini di rischio (causa, evento,
   danno per la Banca) per chi non conosce il tema, senza i motivi dei
   punteggi, che vanno nelle dimensioni (D-68, richiesta dell'utente).
5. Una spiegazione per ognuna delle quattro dimensioni, con le informazioni e
   i documenti che sostengono il valore (per una Velocity non valutata:
   perche' manca); parte dalla motivazione di A1 e **non attribuisce a un
   documento cio' che A1 non gli attribuisce**: A6 non ha letto i documenti,
   vede solo i riferimenti. Se il valore e' stato rettificato, con il motivo
   del validatore (che lo script scrive nelle variazioni come "Rettifica del
   validatore: ...").
6. Fonti copiate identiche: lo script confronta i riferimenti con quelli
   dell'input, carattere per carattere; A6 aggiunge solo "a sostegno di".
7. Niente nomi di persone: non verificabile dallo script, lo guarda chi
   legge le schede prima del comitato.

La rubrica (sezioni 1 e 2) e' nel prompt perche' A6 spiega un valore con il
descrittore: e' anche l'unica fonte di numeri ammessa oltre ai dati.

## Controlli dello script (comando schede)
Schema (`schema_output_A6.json`), poi `controlla_a6`: ciclo uguale all'input,
stessi rischi senza ripetizioni, quattro dimensioni ciascuna una volta, stesse
fonti, nessun numero fuori dai dati. Un problema ferma il comando: nessun file,
il registro non si tocca mai. Senza l'output di A6 il comando produce comunque
le schede con i testi del registro (dal 02/10 il Razionale, il perche' di ogni
valore e, per azioni e KRI, perche' ed effetto atteso, tutti di A1): A6
migliora la lettura, non e' un prerequisito del report. A6 non scrive i testi
di azioni e KRI: li mostra lo script dal registro. Aggiungerli all'output di A6
lo allungherebbe di molto (una risposta troppo lunga in Agent Builder rischia
di arrivare troncata) per riformulare testi gia' brevi.

# A7 Assistente del registro (D-72, 07/10/2026)

**Perche' esiste.** Chi legge il radar chiede "perche'": perche' un rischio ha quei valori, quell'urgenza, quel
livello; perche' un tema dei documenti non e' un rischio. Le risposte stanno gia' nel registro (motivazioni di A1,
decisioni del validatore, segnalazioni, parametri), ma sparse in fogli e archivi.

**Perche' senza allegati.** L'utente vuole un agente "completamente interattivo": lo script scrive la knowledge
(cartella `Kernel/Spiegazioni`) alla fine dei comandi che si lanciano gia'. Un file per posto dell'anagrafica
(`Rischio_01..20.txt`), con nomi fissi, cosi' anche un rischio appena censito e' subito visibile:
la ricerca della knowledge trova il pezzo giusto (un file unico di decine di KB verrebbe letto a pezzi) e un file
aggiornato si reindicizza subito.

**Regole del prompt e perche'.**
- Prima persona (D-87, 29/10): "le valutazioni del registro sono tue", "Ho dato Impatto 4 perche'...", nessun nome
  di agente (nei file della knowledge "A1" e "A8" sono lui), il validatore nominato sempre. Fino al 29/10 A7 doveva
  etichettare ogni frase REGISTRATO / CALCOLATO / LETTURA MIA, con una sezione Limiti fissa: l'utente ha notato che
  "mette sempre le mani avanti", e il prompt glielo chiedeva. Resta la protezione per cui le etichette erano nate (il
  rischio vero di un agente che spiega e' presentare una ricostruzione plausibile come il motivo di chi ha deciso):
  il perche' e' la motivazione scritta nel file, i conti si rifanno con i numeri del file, e solo cio' che il file
  non dice va scritto come "(lettura di oggi, non nel registro)". "Non nel registro: ..." solo se manca un dato.
- Nessun valore nuovo: come A4 e A6, A7 non valuta (D-41); per "dovrebbe essere piu' alto?" indica il descrittore
  e l'evidenza che servirebbe.
- Fenomeni non censiti: il motivo lo scrive A1 nel ciclo (campo `fenomeni_non_censiti`); se manca, A7 cerca nei
  documenti e lo dice. Senza questo campo ogni risposta sarebbe una ricostruzione. Dall'08/10 (D-79) i rischi in
  osservazione e chi e' entrato o uscito dal radar sono in `Ciclo.txt`: per un rischio in osservazione A7 riporta i
  valori, il perche' e' fuori dal radar (CALCOLATO dalla regola), l'orizzonte e il segnale di avvicinamento (regola 4).
- Sintesi per il Quadro: al massimo 600 caratteri, perche' sta in una riga della prima pagina del report.

- Richieste di modifica (regola 8, riscritta il 07/10 sera, D-76): A7 non modifica e non ha un modo manutenzione;
  indica la via (riapri e valida per i valori, celle gialle, testi a mano poi baseline, dismetti).

**Rubrica**: sezioni 1, 2, 3, 8 (dimensioni, rilevanza delle fonti, regole di variazione, urgenza). Prompt 7.769
caratteri dal 29/10 (D-87; 6.891 dal 07/10 sera, D-76; 6.575 fino al 07/10 pomeriggio).

# A8 Evento critico (D-77, 07/10/2026)

**Lunghezze (D-88, 29/10).** A8 scrive lo stesso JSON di A1 e riceve la stessa guida: le lunghezze dei testi dei
rischi (D-86) valgono anche per lui. La tabella ha in piu' le righe dell'analisi dell'evento (evento 300-700,
catena_causale 600-1300, effetto su ogni rischio toccato 150-350, uso di ogni documento 100-250, limiti 150-500):
C10 ne fa un'Osservazione sul ciclo (id_rischio null). Le istruzioni di A8 non cambiano (7.993 caratteri: non c'e'
spazio, e non serve: la tabella e' nell'allegato).

**Testi dei rischi esistenti (D-93, 03/11).** Stesse regole di A1 (scelta dell'utente): per un rischio che rivaluta A8
scrive solo i testi che cambiano, e nella descrizione l'evoluzione e' l'evento; i KRI in vigore restano. Passi 3
("Rivaluta ... dai valori e testi della baseline") e 6 ("KRI e testi: guida") riscritti nello stesso spazio (7.987
caratteri).

**Perche' esiste.** Il ciclo straordinario (D-75) rivaluta pochi rischi per un evento che non puo' aspettare il
trimestre. A1 e' scritto per valutare tutto il registro con la stessa profondita'; per un evento serve l'opposto:
leggere per intero pochi documenti, ricostruire la catena causale e dire quali rischi l'evento tocca e quali no.

**Perche' lo stesso formato di A1.** Allegato (`Input_A8_<AAAAQn-Sk>.txt`), schema e comandi sono gli stessi:
precontrollo, controlli, scrittura e validazione non cambiano e non c'e' un secondo percorso da mantenere. Lo script
non distingue chi ha scritto l'output (A1 sa ancora fare lo straordinario); cambia solo il destinatario dei messaggi
di correzione ("Messaggio per A8", dal periodo `-Sk`).

**Regole del prompt e perche'.**
- Passo 3, "TUTTI e SOLO i rischi_da_rivalutare": i rischi li decide la funzione di rischio; un rischio in piu' o in
  meno e' un fermo C1 (D-75).
- Passo 4, rischio nuovo solo per un meccanismo creato dall'evento: lo straordinario non e' un trimestre anticipato.
  Con `rischi_da_rivalutare` vuoto lo straordinario e' di solo censimento (scelta dell'utente) e serve almeno un
  rischio nuovo.
- `analisi_evento` (scelta dell'utente: nel JSON, struttura del registro invariata): il perche' dello straordinario
  in un posto solo. Non porta valori, quindi non si valida: i valori restano nei rischi. Le istruzioni di dettaglio
  sono nella guida di scrittura dell'allegato, perche' il prompt e' al limite (7.994 caratteri).
- `rischi_toccati` comprende anche i rischi esistenti che A8 non puo' riscrivere: e' il modo di dire alla funzione di
  rischio che forse andavano indicati (lo script lo segnala al validatore, senza fermare).
- Passo 7, "rileggi ogni KRI in vigore dei rischi che riscrivi": in un trimestre un KRI non riletto e' normale (il
  dato arriva al ciclo dopo); nello straordinario lascerebbe Non rilevato proprio il KRI del rischio che sale, e il
  livello di allerta perderebbe l'aggravante (visto nella demo del 07/10). Scelta dell'utente; il controllo C7 lo
  segnala da motivare.
- Modalita' Think deeper: e' il compito piu' profondo, su pochi rischi.

**Rubrica**: sezioni 1-4, come A1 (dimensioni, rilevanza delle fonti, regole di variazione, KRI).

