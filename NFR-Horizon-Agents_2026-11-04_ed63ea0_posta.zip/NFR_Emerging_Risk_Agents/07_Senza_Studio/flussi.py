"""I processi dell'app NFR come sequenze di passi (D-83, tappa M2; TODO AU5).

Ogni processo (settimana, trimestre, straordinario, validazione, schede e report, riapertura, testi a mano,
dismissione, parere di A4...) e' una funzione che parla con il mondo solo attraverso un Ambiente:
  - esegui(argomenti, script=None)  lancia il motore (esecutore.py) e restituisce l'esito;
  - apri(cosa)                      apre un file, una cartella o il link di un agente;
  - copia(testo)                    mette un testo negli appunti (la richiesta per l'agente, una correzione);
  - risposta(agente, istruzioni)    aspetta la risposta copiata dall'agente (appunti o file); None = annullato;
  - attendi_chiusura(file)          aspetta che il registro aperto in Excel sia chiuso;
  - chiedi(titolo, campi)           un modulo da compilare (dict) o None; un campo e' (chiave, etichetta,
                                    predefinito[, scelte[, solo_scelte]]): con le scelte un elenco a discesa;
  - conferma(domanda)               si' o no;
  - mostra(testo, tipo)             un messaggio (info, avviso, errore, ok);
  - modifica_temi(titolo, temi, risposte)  la lista dei temi da verificare da rivedere (P9): la lista confermata, o
                                    None se l'analista annulla.
La finestra (app_nfr.py) realizza l'Ambiente con tkinter; il collaudo con un Ambiente finto, senza persona ne' Excel.
Le regole restano nel motore: qui c'e' solo l'ordine dei passi, i nomi dei file e i testi da dare agli agenti.

Gli agenti restano in Agent Builder: per ognuno l'app prepara i file da allegare in una cartella
(%USERPROFILE%/NFR_Da_allegare/<agente>), apre la cartella e il link dell'agente, mette la richiesta negli appunti e
aspetta la risposta. Tre gesti per l'analista: trascinare i file, incollare la richiesta, premere Copia.
"""

import argparse
import datetime as dt
import json
import os
import shutil
from pathlib import Path

import esecutore
import ingresso
import stato
import temi

QUI = Path(__file__).resolve().parent
AMMINISTRAZIONE = QUI / "amministrazione.py"

# Messaggi base degli agenti (guida, sezione 8).
MESSAGGI = {"A1": "Esegui il ciclo", "A8": "Esegui il ciclo straordinario", "A3": "Esegui l'aggiornamento settimanale",
            "A5": "Esegui i controlli", "A6": "Scrivi le schede", "A4": "Dammi il parere su questa notizia: "}
NOMI = {"A1": "A1 Horizon Scanner", "A3": "A3 Interim Update", "A4": "A4 News Assessor", "A5": "A5 Challenger",
        "A6": "A6 Schede dei rischi", "A7": "A7 Assistente del registro", "A8": "A8 Evento critico"}


# Le operazioni della finestra Admin (D-85), nell'ordine della tabella "Pulsante Admin" della guida.
OPERAZIONI_ADMIN = ["Nuovo registro", "Testi a mano", "Pulizia", "Ritorno", "Annulla", "Ripartenza", "Parcheggi", "Svuota",
                    "Diagnosi"]                 # AU8 (04/11/2026): la diagnosi delle valutazioni passa in Admin


def trimestri_recenti(oggi, quanti=12):
    """I trimestri chiusi piu' recenti, dal piu' vecchio: le scelte per 'trimestre prima del primo da valutare'."""
    k = oggi.year * 4 + (oggi.month - 1) // 3 - 1          # il trimestre prima di quello di oggi
    return [f"{x // 4}Q{x % 4 + 1}" for x in range(k - quanti + 1, k + 1)]


def cicli_validati(uscita, prima_di=None):
    """I cicli dell'archivio con Validazione_<ciclo>.json, dal piu' vecchio; con prima_di solo quelli prima."""
    cartella = Path(uscita) / "Cicli"
    cicli = sorted(c.name for c in cartella.iterdir() if c.is_dir() and (c / f"Validazione_{c.name}.json").exists()) \
        if cartella.is_dir() else []
    return [c for c in cicli if not prima_di or c < prima_di]


class Annullato(Exception):
    """L'analista ha interrotto il processo: niente di male, si riprende dal passo giusto."""


def configurazione():
    """Le chiavi del motore (esegui_ciclo_locale.configurazione) piu' quelle dell'app da configurazione.json:
    link_agenti (piatto o per versione degli agenti), validatore_predefinito, raccolta_su_questo_pc, agenti (Agent Builder
    o Copilot Studio: la versione in uso all'avvio), ascolta_appunti, chiedi_a5."""
    import esegui_ciclo_locale
    conf = esegui_ciclo_locale.configurazione(argparse.Namespace())
    grezza = {}
    if (QUI / "configurazione.json").exists():
        grezza = json.loads((QUI / "configurazione.json").read_text(encoding="utf-8-sig"))
    conf.update(link_agenti=grezza.get("link_agenti") or {}, validatore_predefinito=grezza.get("validatore_predefinito") or "",
                raccolta_su_questo_pc=bool(grezza.get("raccolta_su_questo_pc", True)),
                agenti=grezza.get("agenti") if grezza.get("agenti") in ingresso.ORIGINI else ingresso.ORIGINI[0],
                ascolta_appunti=bool(grezza.get("ascolta_appunti", True)), chiedi_a5=bool(grezza.get("chiedi_a5", True)))
    return conf


class Flussi:
    def __init__(self, amb, conf, schemi=None, cartella_allegati=None):
        self.amb, self.conf = amb, conf
        self.origine = conf.get("agenti") or ingresso.ORIGINI[0]      # Agent Builder o Copilot Studio (si annota)
        self.uscita = Path(conf["cartella_uscita"])
        self.schemi = schemi or ingresso.carica_schemi(conf["kernel"])
        self.allegati = Path(cartella_allegati or Path(os.environ.get("USERPROFILE") or Path.home()) / "NFR_Da_allegare")
        self.admin = False                           # modalita' Admin (D-85): la accende la casella della finestra

    # ------------------------------------------------------------ mattoni
    def esito(self, testo, tipo):
        """La riga sotto il riquadro della risposta (se l'Ambiente la ha: la finestra si', il collaudo no)."""
        funzione = getattr(self.amb, "esito_risposta", None)
        if funzione:
            funzione(testo, tipo)

    def motore(self, *argomenti, script=None):
        """Lancia un comando; mostra l'esito; restituisce il dict dell'esecutore."""
        esito = self.amb.esegui([str(a) for a in argomenti], script)
        tipo = {"OK": "ok", "FERMATO": "avviso"}.get(esito["fascia"], "errore")
        nome = Path(script).stem if script else next((str(a) for a in argomenti if not str(a).startswith("-")), "")
        self.amb.mostra(f"{nome}: {esito['fascia']}. {esito['cosa_fare']}", tipo)
        return esito

    def link(self, agente):
        """Il link dell'agente nella versione in uso: link_agenti piatto ({"A1": ...}) oppure per versione
        ({"Agent Builder": {...}, "Copilot Studio": {...}})."""
        link = self.conf.get("link_agenti") or {}
        if self.origine in link and isinstance(link[self.origine], dict):
            link = link[self.origine]
        return str(link.get(agente) or "")

    def prepara_allegati(self, agente, file):
        cartella = self.allegati / agente
        if cartella.exists():
            shutil.rmtree(cartella, ignore_errors=True)
        cartella.mkdir(parents=True, exist_ok=True)
        for f in file:
            shutil.copy2(f, cartella / Path(f).name)
        return cartella

    def chiedi_ad_agente(self, agente, file, messaggio, periodo, nuova_chat=True, atteso=None):
        """Prepara gli allegati, apre la cartella e l'agente, mette la richiesta negli appunti, aspetta la risposta.
        Unisce le parti di una risposta tagliata. Restituisce l'esito di ingresso.ricevi (agente atteso, file salvato)."""
        atteso = atteso or agente
        if nuova_chat:
            cartella = self.prepara_allegati(agente, file)
            if file:
                self.amb.apri(cartella)
            link = self.link(agente)
            if link.startswith("http"):                # un segnaposto non compilato non si apre
                self.amb.apri(link)
            self.amb.copia(messaggio)
            stato.segna(self.uscita, periodo, f"{agente} richiesto", self.conf.get("utente"))
            istruzioni = (f"{NOMI.get(agente, agente)} ({self.origine}): chat nuova" + (f", trascina i file della cartella {cartella}" if file else "")
                          + ", incolla la richiesta (e' negli appunti) e invia. Poi copia la risposta e incollala qui sotto "
                          "(Ctrl+V), oppure premi Copia sotto la risposta: l'app la prende da sola.")
        else:
            istruzioni = (f"Nella stessa chat di {NOMI.get(agente, agente)}: incolla il messaggio (e' negli appunti) e invia. "
                          "Poi copia la risposta e incollala qui sotto (o premi Copia).")
        parti = []
        while True:
            testo = self.amb.risposta(atteso, istruzioni)
            if testo is None:
                raise Annullato(f"risposta di {atteso} non arrivata")
            parti.append(testo)
            r = ingresso.ricevi(ingresso.unisci(parti) if len(parti) > 1 else testo, self.schemi, self.uscita, atteso,
                                self.origine)
            if r["stato"] == ingresso.TRONCATA:
                self.esito(f"Risposta tagliata ({sum(len(p) for p in parti):,} caratteri finora): nella stessa chat scrivi "
                           "\"continua\" (e' negli appunti) e incolla qui il resto.".replace(",", "."), "avviso")
                self.amb.copia("continua")
                istruzioni = (f"La risposta di {atteso} e' tagliata: scrivi \"continua\" nella stessa chat (e' negli appunti), "
                              "poi premi Copia sotto il resto della risposta.")
                continue
            if r["agente"] != atteso:
                self.esito(r["avviso"] or f"Non e' la risposta di {atteso}.", "avviso")
                self.amb.mostra(r["avviso"] or f"Non e' la risposta di {atteso}.", "avviso")
                parti = []
                continue
            if r["errori"] and atteso not in ("A1", "A8"):     # A1 e A8: lo schema lo guarda il precontrollo
                self.amb.copia(ingresso.messaggio_correzione(atteso, r["errori"]))
                self.esito(f"Risposta di {atteso} salvata ma non rispetta lo schema ({len(r['errori'])} punti): il "
                           "messaggio di correzione e' negli appunti.", "avviso")
                self.amb.mostra(f"La risposta di {atteso} non rispetta lo schema ({len(r['errori'])} punti): il messaggio "
                                "di correzione e' negli appunti.", "avviso")
                parti = []
                istruzioni = (f"Nella stessa chat di {NOMI.get(atteso, atteso)}: incolla il messaggio di correzione e invia. "
                              "Poi premi Copia sotto la risposta.")
                continue
            stato.segna(self.uscita, periodo, f"{atteso} ricevuto", self.conf.get("utente"), f"{r['file']} ({self.origine})")
            lunghezza = len(ingresso.unisci(parti) if len(parti) > 1 else testo)
            self.esito(f"Ricevuto: {atteso} ({self.origine}), {lunghezza:,} caratteri, salvato in ".replace(",", ".")
                       + (f"{Path(r['file']).parent.name}\\{Path(r['file']).name}" if r.get("file") else "In_arrivo"), "ok")
            return r

    def gia_copiata(self, agente, nome):
        """Una risposta gia' in In_arrivo (processo interrotto e ripreso): si usa se l'analista conferma."""
        file = self.uscita / ingresso.CARTELLA / nome
        if file.exists() and self.amb.conferma(f"In In_arrivo c'e' gia' la risposta di {agente} ({nome}). Usarla senza "
                                               f"richiederla ad {agente}?"):
            return {"stato": ingresso.OK, "agente": agente, "file": file, "errori": [], "avviso": None}
        return None

    def correzione_a1(self, ciclo):
        return self.uscita / "Cicli" / ciclo / f"Correzione_A1_{ciclo}.txt"

    def registro_in_excel(self):
        """Apre il registro visibile (per la griglia o i testi) e aspetta che l'analista lo chiuda."""
        self.amb.apri(self.conf["workbook"])
        self.amb.attendi_chiusura(self.conf["workbook"])

    # ------------------------------------------------------------ processi
    def valutazione(self, periodo, agente, file_agente, con_a5=False):
        """A1 (o A8) -> precontrollo con il giro di correzione -> A5 facoltativo -> trimestrale (con il suo giro)."""
        r = (self.gia_copiata(agente, f"{agente}_{periodo}.json")
             or self.chiedi_ad_agente(agente, file_agente, MESSAGGI[agente], periodo))
        while True:
            pre = self.motore("precontrollo", "--payload", r["file"])
            conti = esecutore.esito_precontrollo(pre["uscita"])
            if pre["fascia"] == "ERRORE TECNICO" or conti is None:
                raise Annullato("precontrollo non riuscito")
            da_correggere, da_verificare, testi = conti
            # D-86: testi troppo corti (C10) = da allungare, ma si puo' saltare: in validazione restano osservazioni
            if not da_correggere and testi and self.amb.conferma(
                    f"{agente} e' stato troppo sintetico: {testi} rischi hanno testi sotto le lunghezze minime (descrizione, "
                    f"razionale, azioni o KRI). Chiedergli di allungarli nella stessa chat (consigliato)? No = si prosegue: "
                    "in validazione resteranno come osservazioni."):
                pass                                 # al messaggio di correzione, qui sotto
            elif not da_correggere and not (da_verificare and self.amb.conferma(
                    f"Il precontrollo ha {da_verificare} punti da verificare (andrebbero in validazione come segnalazioni). "
                    f"Farli rivedere prima ad {agente}?")):
                break
            self.amb.copia(self.correzione_a1(periodo).read_text(encoding="utf-8"))
            r = self.chiedi_ad_agente(agente, [], "", periodo, nuova_chat=False)
        a5 = None
        # A5 facoltativo (D-71): con la casella spuntata si fa; altrimenti l'app lo propone qui, a precontrollo superato,
        # quando la scelta si capisce (richiesta dell'utente del 29/10). chiedi_a5 = false in configurazione: niente domanda.
        if con_a5 or (self.conf.get("chiedi_a5", True) and self.amb.conferma(
                f"Precontrollo dell'output di {agente} superato. Passare anche da A5 Challenger prima di scrivere il ciclo? "
                "(Facoltativo: controlla la plausibilita' delle valutazioni; i suoi rilievi vanno in validazione.)")):
            a5 = self.chiedi_ad_agente("A5", [self.uscita / f"Input_A5_{periodo}.txt"], MESSAGGI["A5"], periodo)
        while True:
            argomenti = ["trimestrale", "--payload", r["file"]] + (["--challenger", a5["file"]] if a5 else [])
            es = self.motore(*argomenti)
            if es["fascia"] != "FERMATO" or not self.correzione_a1(periodo).exists():
                return es
            self.amb.copia(self.correzione_a1(periodo).read_text(encoding="utf-8"))
            r = self.chiedi_ad_agente(agente, [], "", periodo, nuova_chat=False)
            if a5:
                a5 = self.chiedi_ad_agente("A5", [self.uscita / f"Input_A5_{periodo}.txt"], MESSAGGI["A5"], periodo)

    def temi_da_verificare(self, prima_di_a1=False):
        """P9 (D-98): la lista dei temi che l'analista chiede ad A1 di verificare, da vedere e modificare; prima di ogni
        ciclo trimestrale l'app la propone (Conferma = va bene cosi', anche senza modifiche). Il file e' condiviso: se un
        collega lo ha cambiato nel frattempo, il salvataggio si ferma."""
        file = temi.file_temi(self.conf)
        elenco, impronta = temi.leggi(file), temi.impronta(file)
        titolo = ("Prima di A1: rivedi i temi da verificare (Conferma per proseguire)" if prima_di_a1
                  else "Temi da verificare")
        nuovi = self.amb.modifica_temi(titolo, elenco, self.risposte_temi())
        if nuovi is None:
            return None
        try:
            nuovi = temi.normalizza(nuovi)
            if nuovi != elenco:
                temi.scrivi(file, nuovi, impronta)
        except (ValueError, RuntimeError) as ex:
            self.amb.mostra(f"Temi da verificare non salvati: {ex}", "errore")
            return None
        self.amb.mostra(f"Temi da verificare: {len(temi.aperti(nuovi))} aperti" + (f", salvati in {file}" if nuovi != elenco
                                                                                    else ", senza modifiche") + ".", "ok")
        return nuovi

    def risposte_temi(self):
        """Le risposte di A1 ai temi nell'ultimo ciclo che li aveva: {codice: "2026Q4: NFR-07, ..."}."""
        cartella = self.uscita / "Cicli"
        file = sorted(cartella.glob("*/Temi_*.json")) if cartella.is_dir() else []
        out = {}
        for f in file:                               # dal piu' vecchio: vince l'ultima risposta
            try:
                for t in json.loads(f.read_text(encoding="utf-8")):
                    out[t["codice"]] = f"{f.parent.name}: {', '.join(t.get('risposte') or ['senza risposta'])}"
            except (OSError, ValueError, KeyError, TypeError):
                continue
        return out

    def trimestrale(self, con_a5=False):
        s = stato.leggi(self.conf)
        if s["ciclo_corrente"] and (not s["validato"] or s["riapertura"]):
            self.amb.mostra(f"Il ciclo {s['ciclo_corrente']} non e' validato: prima la validazione.", "avviso")
            return None
        self.temi_da_verificare(prima_di_a1=True)    # P9: entrano nella baseline qui sotto
        if self.motore("baseline")["fascia"] != "OK":
            return None
        ciclo = stato.leggi(self.conf)["da_valutare"]
        es = self.valutazione(ciclo, "A1", [self.uscita / f"Input_A1_{ciclo}.txt"], con_a5)   # nomi: input_a1, D-84
        if es["fascia"] == "OK" and self.amb.conferma(f"Ciclo {ciclo} scritto. Passare alla validazione adesso?"):
            return self.validazione()
        return es

    def straordinario(self, con_a5=False, solo_censimento=False):
        """Ciclo straordinario (D-75, D-77). Con solo_censimento (AU8, pulsante "Aggiungi un rischio (A8)") nessun rischio
        da rivalutare: A8 censisce i rischi nuovi che l'evento o il fatto crea, poi controlli e approvazione come sempre."""
        campi = [("motivo", "L'evento e perche' non puo' aspettare il trimestre (almeno 20 caratteri)" if not solo_censimento
                  else "Il rischio da aggiungere: il fatto o il documento che lo fa nascere (almeno 20 caratteri)", ""),
                 ("decisore", "Chi decide (funzione o comitato)", self.conf.get("validatore_predefinito") or ""),
                 ("data", "Data di riferimento AAAA-MM-GG (vuoto = oggi)", "")]
        if not solo_censimento:
            campi.insert(0, ("rischi", "Rischi da rivalutare, separati da virgole (vuoto = solo censimento di rischi nuovi)", ""))
        dati = self.amb.chiedi("Aggiungi un rischio: ciclo straordinario di solo censimento con A8 (decide la funzione di "
                               "rischio)" if solo_censimento else "Ciclo straordinario (decide la funzione di rischio)", campi)
        if not dati:
            return None
        argomenti = ["baseline", "--straordinario", "--motivo", dati["motivo"], "--decisore", dati["decisore"]]
        argomenti += (["--rischi", dati["rischi"]] if dati.get("rischi") else []) + (["--data", dati["data"]] if dati.get("data") else [])
        if self.motore(*argomenti)["fascia"] != "OK":
            return None
        periodo = stato.leggi(self.conf)["da_valutare"]
        self.amb.mostra(f"Per A8 servono anche i documenti dell'evento: trascinali nella chat insieme a Input_A8_{periodo}.txt.", "info")
        es = self.valutazione(periodo, "A8", [self.uscita / f"Input_A8_{periodo}.txt"], con_a5)
        if es["fascia"] == "OK" and self.amb.conferma(f"Straordinario {periodo} scritto. Passare alla validazione adesso?"):
            return self.validazione()
        return es

    def da_approvare(self):
        """AU8: che cosa aspetta l'approvazione, [(periodo, come lo dice il pulsante)]: il ciclo scritto o riaperto e la
        settimana scritta e non ancora approvata."""
        s = stato.leggi(self.conf)
        out = []
        c = s["ciclo_corrente"]
        if c and (not s["validato"] or s["riapertura"]):
            out.append((c, f"lo straordinario {c}" if "-S" in c else f"il trimestre {c}"))
        w = s["settimana"]
        if w["scritta"] and not w["validata"]:
            out.append((w["lunedi"], f"le notizie del {dt.date.fromisoformat(w['lunedi']):%d/%m}"))
        return out

    def approva(self):
        """AU8: il pulsante "Approva": il periodo in attesa; se sono due, chiede quale."""
        attesa = self.da_approvare()
        if not attesa:
            self.amb.mostra("Niente da approvare: nessun ciclo ne' settimana scritti in attesa.", "info")
            return None
        periodo = attesa[0][0]
        if len(attesa) > 1:
            scelte = [f"{p} ({etichetta})" for p, etichetta in attesa]
            dati = self.amb.chiedi("Che cosa approvi?", [("periodo", "Periodo da approvare", scelte[0], scelte, True)])
            if not dati:
                return None
            periodo = dati["periodo"].split(" ", 1)[0]
        return self.validazione(periodo)

    def aggiungi_rischio(self, con_a5=False):
        """AU8: "Aggiungi un rischio (A8)" = ciclo straordinario di solo censimento."""
        return self.straordinario(con_a5, solo_censimento=True)

    def validazione(self, periodo=None):
        s = stato.leggi(self.conf)
        periodo = periodo or s["ciclo_corrente"]
        if not periodo:
            self.amb.mostra("Niente da validare.", "info")
            return None
        validatore = self.conf.get("validatore_predefinito")
        dati = self.amb.chiedi(f"Validazione del periodo {periodo}", [("validatore", "Chi valida (funzione o comitato)", validatore or "")])
        if not dati or not dati.get("validatore"):
            return None
        self.amb.mostra("Si apre il registro sul foglio Validazione: cambia solo le celle gialle, la Motivazione e Respingi; "
                        "poi salva e chiudi Excel.", "info")
        while True:
            self.registro_in_excel()
            es = self.motore("valida", "--periodo", periodo, "--validatore", dati["validatore"])
            if es["fascia"] != "FERMATO" or not self.amb.conferma("La validazione non e' applicata (motivi qui sopra). "
                                                                   "Riaprire il registro per correggere la griglia?"):
                break
        # P17: le rettifiche di una riapertura cambiano i valori, non i testi che li motivano: l'elenco e Testi a mano.
        if es["fascia"] == "OK" and "Q" in periodo and "TESTI DA RILEGGERE" in es["uscita"] and self.amb.conferma(
                "Le rettifiche della riapertura hanno cambiato dei valori: i testi che li motivano (razionali, note dei "
                "KRI) sono quelli di prima. L'elenco e' qui sopra. Correggerli adesso con Testi a mano? (Si annulla con "
                "Admin -> Annulla; No = si possono correggere dopo da Admin -> Testi a mano.)"):
            self.testi_a_mano(lambda *a: self.motore("--admin", *a, script=AMMINISTRAZIONE),
                              motivo=f"Testi da rileggere dopo le rettifiche della riapertura del ciclo {periodo}")
        if es["fascia"] == "OK" and "Q" in periodo and self.amb.conferma("Validato. Fare adesso le schede dei rischi?"):
            self.schede()
        return es

    def schede(self):
        if self.motore("schede-input")["fascia"] != "OK":
            return None
        ciclo = stato.leggi(self.conf)["ciclo_corrente"]
        if self.amb.conferma("Usare A6 per i testi delle schede? (No = schede con i testi di A1 dal registro)"):
            r = (self.gia_copiata("A6", f"A6_{ciclo}.json")
                 or self.chiedi_ad_agente("A6", [self.uscita / "Cicli" / ciclo / f"Input_A6_{ciclo}.json"], MESSAGGI["A6"], ciclo))
            while True:
                es = self.motore("schede", "--payload", r["file"])
                quanti, corti = esecutore.testi_corti_a6(es["uscita"]) if es["fascia"] == "OK" else (0, [])
                # D-88: schede scritte ma testi troppo corti: si propone di farli allungare ad A6 (si puo' saltare)
                if es["fascia"] == "OK" and quanti and self.amb.conferma(
                        f"A6 e' stato troppo sintetico: {quanti} testi delle schede sono sotto le lunghezze minime. "
                        "Chiedergli di allungarli nella stessa chat (consigliato)? No = si tengono le schede come sono."):
                    self.amb.copia(ingresso.messaggio_correzione("A6", [f"testo troppo corto, allungalo con contenuto "
                                                                        f"(non con ripetizioni): {x}" for x in corti]))
                    r = self.chiedi_ad_agente("A6", [], "", ciclo, nuova_chat=False)
                    continue
                if es["fascia"] != "FERMATO":
                    break
                self.amb.copia(ingresso.messaggio_correzione("A6", [x.strip(" -") for x in es["uscita"].splitlines()
                                                                     if x.strip().startswith("- ")]))
                r = self.chiedi_ad_agente("A6", [], "", ciclo, nuova_chat=False)
        else:
            es = self.motore("schede")
        if not stato.leggi(self.conf)["report"]:
            self.motore("report")
        self.amb.apri(self.uscita / "Cicli" / ciclo)
        return es

    def report(self):
        es = self.motore("report")
        ciclo = stato.leggi(self.conf)["ciclo_corrente"]
        if es["fascia"] == "OK" and ciclo:
            self.amb.apri(self.uscita / "Cicli" / ciclo)
        return es

    def settimanale(self):
        s = stato.leggi(self.conf)
        lun = s["settimana"]["lunedi"]
        news = Path(self.conf.get("news_inbox"))
        if not s["settimana"]["raccolta"]:
            if self.conf.get("raccolta_su_questo_pc", True):
                self.motore("--news-inbox", news, script=esecutore.RACCOLTA)
            else:
                self.amb.mostra("La raccolta delle notizie non e' ancora arrivata (gira su un altro PC): si puo' "
                                "proseguire con i soli file manuali e i siti di A3.", "avviso")
        manuali = news / lun / "Manuali"
        manuali.mkdir(parents=True, exist_ok=True)
        self.amb.apri(manuali)
        if not self.amb.conferma("Aggiunti in Manuali i file che non arrivano dai feed (circolari, rapporti)? "
                                 "Si' per proseguire con A3."):
            return None
        r = (self.gia_copiata("A3", f"A3_{lun}.json")
             or self.chiedi_ad_agente("A3", [self.uscita / "Input_A3_A4.txt"], MESSAGGI["A3"], lun))
        while True:
            es = self.motore("settimanale", "--payload", r["file"])
            if es["fascia"] != "FERMATO":
                break
            motivo = es["uscita"].split("FERMATO", 1)[-1].strip().splitlines()
            self.amb.copia(ingresso.messaggio_correzione("A3", [m for m in motivo[1:] if m.strip()] or motivo))
            r = self.chiedi_ad_agente("A3", [], "", lun, nuova_chat=False)
        if es["fascia"] == "OK" and self.amb.conferma("Settimana scritta. Validare adesso le notizie (facoltativo)?"):
            return self.validazione(lun)
        return es

    def riapertura(self):
        dati = self.amb.chiedi("Riaprire la validazione del ciclo corrente",
                               [("rischi", "Solo questi rischi, separati da virgole (vuoto = tutto)", "")])
        if dati is None:
            return None
        es = self.motore("riapri", *(["--rischi", dati["rischi"]] if dati.get("rischi") else []))
        return self.validazione() if es["fascia"] == "OK" else es

    def testi_a_mano(self, m, motivo=""):
        """Admin -> Testi a mano (D-90): prima i controlli (una riapertura aperta o un ciclo da validare portano alla
        Validazione, non a un report che si ferma), poi la copia del registro nel parcheggio, Excel, e la fine. La propone
        anche la Validazione dopo le rettifiche di una riapertura (P17), con l'elenco dei testi da rileggere."""
        import amministrazione as amm
        try:
            ciclo = amm.controlli_testi(stato.leggi(self.conf))
        except amm.Fermo as ex:
            self.amb.mostra(str(ex), "avviso")
            return self.validazione() if self.amb.conferma("Passare alla Validazione adesso?") else None
        d = self.amb.chiedi("Testi a mano: correggere solo le colonne di testo di un ciclo validato", [
            ("motivo", "Che cosa correggi e perche' (almeno 10 caratteri; resta nell'atto)", motivo)])
        if not d:
            return None
        es = m("testi", "--motivo", d["motivo"])
        if es["fascia"] != "OK":
            return es
        from esegui_ciclo_locale import riga_testo_da_rileggere
        voci = amm.testi_da_rileggere(self.conf, ciclo)
        self.amb.mostra("Si apre il registro: correggi SOLO le colonne di testo (descrizioni, razionali, KRI, azioni), mai "
                        "ID, numeri, date o righe; poi salva e chiudi Excel."
                        + ("\n\nTesti da rileggere dopo le rettifiche della riapertura (P17):\n"
                           + "\n".join(f"- {riga_testo_da_rileggere(v)}" for v in voci) if voci else ""), "info")
        self.registro_in_excel()
        return m("testi-fine")

    def dismetti(self):
        dati = self.amb.chiedi("Dismettere un rischio (decide la funzione di rischio)", [
            ("rischio", "ID del rischio (NFR-nn)", ""), ("motivazione", "Perche' (almeno 10 caratteri)", ""),
            ("decisore", "Chi ha deciso", self.conf.get("validatore_predefinito") or "")])
        if not dati:
            return None
        return self.motore("dismetti", "--rischio", dati["rischio"], "--motivazione", dati["motivazione"],
                           "--decisore", dati["decisore"])

    def parere_a4(self):
        r = self.chiedi_ad_agente("A4", [self.uscita / "Input_A3_A4.txt"], MESSAGGI["A4"], f"A4_{dt.date.today():%Y%m%d}")
        self.amb.mostra(f"Parere archiviato: {r['file']}", "ok")
        if ingresso.proposta_straordinario(Path(r["file"]).read_text(encoding="utf-8")):
            self.amb.mostra("A4 propone un CICLO STRAORDINARIO: decide la funzione di rischio (pulsante Straordinario).", "avviso")
        return r

    def assistente_a7(self):
        link = self.link("A7")
        if link.startswith("http"):
            self.amb.apri(link)
        else:
            self.amb.mostra("Link di A7 non configurato (configurazione.json, link_agenti).", "avviso")

    def diagnosi(self):
        return self.motore("diagnosi")

    def mensile(self):
        """P7 (D-100): il riepilogo delle settimane di un mese, in Excel e in HTML (solo lettura del registro)."""
        dati = self.amb.chiedi("Riepilogo mensile", [("mese", "Mese AAAA-MM (vuoto = l'ultimo mese con settimane nel registro)", "")])
        if dati is None:
            return None
        es = self.motore("mensile", *(["--mese", dati["mese"]] if dati.get("mese") else []))
        if es["fascia"] == "OK":
            self.amb.apri(self.uscita / "Mensili")
        return es

    def amministrazione(self, operazione=None):
        """Tappa M5 (solo in modalita' Admin, D-85): un'operazione della finestra Admin (OPERAZIONI_ADMIN). Niente si
        cancella subito (tranne svuota, dopo il tempo minimo): tutto va nel parcheggio con l'atto. Le operazioni le fa
        amministrazione.py (Nuovo registro: inizializza e baseline del motore); qui i moduli, con le scelte possibili, e
        le conferme. Senza operazione la chiede (riga di comando dell'app o collaudo)."""
        if not self.admin:
            self.amb.mostra("Le funzioni amministrative si usano in modalita' Admin (D-85): pulsante Admin della finestra.",
                            "avviso")
            return None
        if operazione is None:
            dati = self.amb.chiedi("Amministrazione (modalita' Admin)", [
                ("operazione", "Operazione: " + ", ".join(o.lower() for o in OPERAZIONI_ADMIN), "pulizia", OPERAZIONI_ADMIN)])
            if not dati:
                return None
            operazione = dati["operazione"]
        op = operazione.strip().lower()
        m = lambda *a: self.motore("--admin", *a, script=AMMINISTRAZIONE)
        decisore = self.conf.get("validatore_predefinito") or ""
        lunedi = (dt.date.today() - dt.timedelta(days=dt.date.today().weekday())).isoformat()
        trimestri = trimestri_recenti(dt.date.today())
        if op == "parcheggi":
            return m("parcheggi")
        if op == "diagnosi":
            return self.diagnosi()
        if op == "testi a mano":
            return self.testi_a_mano(m)
        if op in ("pulizia", "svuota"):
            es = m(op)
            pronto = es["fascia"] == "OK" and f"{op} --esegui" in es["uscita"]
            domanda = ("Spostare nel parcheggio gli elementi dell'anteprima (righe qui sopra)?" if op == "pulizia" else
                       "Cancellare PER SEMPRE i parcheggi elencati qui sopra? L'elenco resta nella traccia.")
            return m(op, "--esegui") if pronto and self.amb.conferma(domanda) else es
        if op == "nuovo registro":
            if Path(self.conf["workbook"]).exists():
                self.amb.mostra(f"Il registro c'e' gia' ({Path(self.conf['workbook']).name}): per ricominciare da zero si usa "
                                "Ripartenza, che mette il vecchio nel parcheggio.", "avviso")
                return None
            d = self.amb.chiedi("Nuovo registro, vuoto", [
                ("ciclo_precedente", "Trimestre PRIMA del primo da valutare (es. 2025Q4 per cominciare dal 2026Q1)",
                 trimestri[-1], trimestri),
                ("settimana", "Lunedi' della settimana corrente del registro (AAAA-MM-GG)", lunedi)])
            if not d:
                return None
            es = self.motore("inizializza", "--ciclo-precedente", d["ciclo_precedente"], "--settimana", d["settimana"])
            return self.motore("baseline") if es["fascia"] == "OK" else es
        if op == "ritorno":
            s = stato.leggi(self.conf)
            corrente = s["ciclo_corrente"]
            cicli = cicli_validati(self.uscita, prima_di=corrente)
            if not cicli:
                self.amb.mostra(f"Nessun ciclo validato prima del corrente ({corrente or 'nessuno'}): niente a cui tornare.",
                                "avviso")
                return None
            d = self.amb.chiedi(f"Ritorno a un ciclo validato (ora il ciclo corrente e' {corrente})", [
                ("ciclo", "Ciclo validato a cui tornare: il registro torna com'era alla sua validazione", cicli[-1], cicli, True),
                ("motivo", "Perche' (almeno 20 caratteri; resta nell'atto)", ""), ("decisore", "Chi ha deciso", decisore),
                ("conferma", "Riscrivi il ciclo per confermare", "")])
            return m("ritorno", "--ciclo", d["ciclo"], "--motivo", d["motivo"], "--decisore", d["decisore"],
                     "--conferma", d["conferma"]) if d else None
        if op == "annulla":
            import amministrazione as amm
            attivi = [f"{c.name}   ({a.get('operazione')} del {str(a.get('quando', '')).replace('T', ' ')} di {a.get('utente')})"
                      for c, a in amm.elenco_parcheggi(self.conf) if a.get("stato") == "attivo"]
            if not attivi:
                self.amb.mostra("Nessun parcheggio da rimettere a posto.", "info")
                return None
            d = self.amb.chiedi("Annullare un'operazione (rimettere a posto un parcheggio)", [
                ("parcheggio", "Parcheggio da rimettere a posto", attivi[-1], attivi, True),
                ("motivo", "Perche' (almeno 10 caratteri)", "")])
            return m("annulla", "--parcheggio", d["parcheggio"].split()[0], "--motivo", d["motivo"]) if d else None
        if op == "ripartenza":
            nome = Path(self.conf["workbook"]).name
            d = self.amb.chiedi("Ripartenza da zero: registro nuovo, il vecchio e l'archivio dei cicli nel parcheggio", [
                ("motivo", "Perche' (almeno 20 caratteri)", ""), ("decisore", "Chi ha deciso", decisore),
                ("ciclo_precedente", "Trimestre PRIMA del primo da valutare (es. 2025Q4 per cominciare dal 2026Q1)",
                 trimestri[-1], trimestri),
                ("settimana", "Lunedi' della settimana corrente del registro nuovo (AAAA-MM-GG)", lunedi),
                ("conferma", f"Riscrivi il nome del registro ({nome}) per confermare", "")])
            return m("ripartenza", "--motivo", d["motivo"], "--decisore", d["decisore"], "--ciclo-precedente",
                     d["ciclo_precedente"], "--settimana", d["settimana"], "--conferma", d["conferma"]) if d else None
        self.amb.mostra(f"Operazione {operazione!r} sconosciuta: " + ", ".join(OPERAZIONI_ADMIN) + ".", "avviso")
        return None

    def verifica_pc(self):
        """Verifica del PC (tappa M3): una riga per voce nell'uscita, il file nell'archivio (Verifiche_PC)."""
        es = self.motore(script=QUI / "verifica_pc.py")
        if es["fascia"] != "OK":
            self.amb.mostra("Verifica del PC: ci sono punti NO (righe qui sopra). Sistemarli, anche con installa.cmd, "
                            "e rifare la verifica.", "avviso")
        return es

    def sblocca(self):
        dati = self.amb.chiedi("Togliere il lucchetto del registro (solo se e' rimasto per errore)",
                               [("motivo", "Perche' (almeno 10 caratteri; resta registrato)", "")])
        return self.motore("sblocca", "--motivo", dati["motivo"]) if dati else None

    def prossimo(self):
        """Il passo che lo stato propone (pulsante grande della finestra)."""
        s = stato.leggi(self.conf)
        chiave = s["prossimo"]["chiave"]
        azioni = {"baseline": lambda: self.motore("baseline"), "validazione": self.validazione, "trimestrale": self.trimestrale,
                  "straordinario": self._riprendi_straordinario, "report": self.report, "schede": self.schede,
                  "settimanale": self.settimanale, "valida_settimana": lambda: self.validazione(s["settimana"]["lunedi"])}
        if chiave in azioni:
            return azioni[chiave]()
        self.amb.mostra(s["prossimo"]["titolo"], "info")
        return None

    def _riprendi_straordinario(self):
        """Uno straordinario gia' deciso (baseline --straordinario fatto): da A8 in poi."""
        periodo = stato.leggi(self.conf)["da_valutare"]
        es = self.valutazione(periodo, "A8", [self.uscita / f"Input_A8_{periodo}.txt"])
        if es["fascia"] == "OK" and self.amb.conferma(f"Straordinario {periodo} scritto. Passare alla validazione adesso?"):
            return self.validazione()
        return es
