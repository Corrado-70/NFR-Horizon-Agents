"""App NFR Horizon Scan: la finestra che guida l'analista (D-83, tappa M2; TODO AU5).

Si apre con un doppio clic su NFR.cmd. In alto lo stato del processo, letto dall'archivio condiviso (stato.py) e
aggiornato ogni mezzo minuto; sotto il pulsante del prossimo passo e uno per processo; al centro il passo in corso, con
le istruzioni per l'agente; in basso l'uscita del motore e l'esito colorato.

I processi sono in flussi.py: qui c'e' solo l'Ambiente che li collega alla finestra. Ogni processo gira in un thread
a parte, perche' il motore impiega minuti; le richieste di un processo alla finestra (un messaggio, una domanda, la
risposta di un agente) passano da una coda al thread della finestra, l'unico che puo' toccare tkinter.

Le risposte degli agenti si incollano (Ctrl+V) nel riquadro "Risposta dell'agente" della finestra; in piu', se
ascolta_appunti e' acceso, l'app le prende da sola quando si preme Copia sotto la risposta (appunti.py); oppure da un
file ("Scegli file..."). La casella "Agenti" dice se le risposte vengono da Agent Builder o da Copilot Studio: nomi,
cartella e registro sono gli stessi, l'origine si annota. Il registro lo apre Excel, visibile, solo per la griglia di validazione e per i testi a mano;
nel registro scrive solo il motore.
"""

import datetime as dt
import os
import queue
import threading
import time
import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import filedialog, messagebox, scrolledtext, ttk

import aiuto
import amministrazione
import appunti
import esecutore
import flussi
import stato
from esegui_ciclo_locale import aperto_qui

COLORI = {"ok": "#2E7D32", "avviso": "#B26A00", "errore": "#C62828", "info": "#1F3864"}
AGGIORNA_MS = 30000
# Che cosa aspettarsi da un comando del motore, scritto nel passo in corso mentre lavora (richiesta dell'utente del 29/10).
DURATA = {"precontrollo": "pochi secondi, senza Excel", "griglia": "Excel in background, meno di un minuto",
          "sblocca": "pochi secondi, senza Excel", "raccogli_notizie": "qualche minuto, legge le fonti in rete",
          "verifica_pc": "meno di un minuto, apre il registro in sola lettura",
          "amministrazione": "da pochi secondi (parcheggi, pulizia) a qualche minuto con Excel (ritorno, ripartenza)"}
DURATA_EXCEL = "Excel in background, di solito qualche minuto"
NESSUN_PROCESSO = ("Nessun processo in corso. Passa con il mouse su un pulsante per sapere che cosa fa; Aiuto (F1) per "
                   "la guida dell'app e dei processi.")
STILI_AIUTO = {"titolo": ("Segoe UI", 14, "bold"), "sottotitolo": ("Segoe UI", 11, "bold"), "voce": ("Segoe UI", 10),
               "elenco": ("Segoe UI", 10), "testo": ("Segoe UI", 10), "codice": ("Consolas", 9)}


class Suggerimento:
    """Il riquadro che compare passando con il mouse su un pulsante: il testo viene dalla guida (aiuto.py)."""

    def __init__(self, widget, testo):
        self.widget, self.testo, self.finestra, self.attesa = widget, testo, None, None
        widget.bind("<Enter>", lambda ev: self._prepara(), add="+")
        widget.bind("<Leave>", lambda ev: self._chiudi(), add="+")
        widget.bind("<ButtonPress>", lambda ev: self._chiudi(), add="+")

    def _prepara(self):
        self._chiudi()
        self.attesa = self.widget.after(600, self._mostra)

    def _mostra(self):
        testo = self.testo() if callable(self.testo) else self.testo
        if not testo:
            return
        x = self.widget.winfo_rootx() + 10
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 4
        self.finestra = tk.Toplevel(self.widget)
        self.finestra.wm_overrideredirect(True)
        self.finestra.wm_geometry(f"+{x}+{y}")
        tk.Label(self.finestra, text=testo, justify="left", wraplength=560, background="#FFFDE7", relief="solid",
                 borderwidth=1, font=("Segoe UI", 9), padx=8, pady=6).pack()

    def _chiudi(self):
        if self.attesa:
            self.widget.after_cancel(self.attesa)
            self.attesa = None
        if self.finestra:
            self.finestra.destroy()
            self.finestra = None


RIGA_DESCRIZIONE = "ⓘ Passa sopra un pulsante per sapere che cosa fa."


def ultimo_mese_completo(oggi=None):
    """Il mese prima di quello di oggi (AAAA-MM): il mese su cui gira il report mensile delle notizie."""
    oggi = oggi or dt.date.today()
    return (oggi.replace(day=1) - dt.timedelta(days=1)).strftime("%Y-%m")


def etichette_uscite(s, attesa, oggi=None):
    """AU8: i nomi dei pulsanti di "Approvazioni e report" con il periodo su cui lavorano, dallo stato del processo."""
    c = s.get("ciclo_corrente")
    pronto = bool(c and s.get("validato") and not s.get("riapertura"))
    if not attesa:
        approva = "Approva (niente in attesa)"
    elif len(attesa) == 1:
        approva = f"Approva {attesa[0][1]}"
    else:
        approva = "Approva: " + " o ".join(e.split(" ", 1)[1] for _, e in attesa)
    return {"Approva": approva,
            "Prepara le schede (A6)": f"Prepara le schede (A6) del {c}" if pronto else "Prepara le schede (A6): dopo l'approvazione",
            "Genera report": f"Genera report del {c}" if pronto else "Genera report: dopo l'approvazione",
            "Report mensile notizie": f"Report mensile notizie ({ultimo_mese_completo(oggi)})"}


class AmbienteTk:
    """L'Ambiente di flussi.py sulla finestra. I metodi si chiamano dal thread del processo."""

    def __init__(self, app):
        self.app = app

    # chiamata al thread della finestra e attesa del risultato
    def _main(self, funzione, *argomenti):
        if threading.current_thread() is threading.main_thread():
            return funzione(*argomenti)
        evento, scatola = threading.Event(), {}

        def esegui():
            try:
                scatola["v"] = funzione(*argomenti)
            except Exception as ex:                  # noqa: BLE001 - riportata al thread del processo
                scatola["e"] = ex
            evento.set()
        self.app.coda.put(esegui)
        evento.wait()
        if "e" in scatola:
            raise scatola["e"]
        return scatola.get("v")

    def esegui(self, argomenti, script=None):
        programma = Path(script).stem if script else "esegui_ciclo_locale"
        comando = next((str(a) for a in argomenti if not str(a).startswith("-")), programma) if not script else programma
        self.app.coda.put(lambda: self.app.comando_iniziato(comando, f"{programma} {' '.join(map(str, argomenti))}"))
        es = esecutore.esegui(argomenti, self.app.conf["cartella_uscita"], self.app.conf.get("utente") or "",
                              su_riga=lambda r: self.app.coda.put(lambda: self.app.scrivi_log(r)),
                              script=script or esecutore.MOTORE)
        self.app.coda.put(lambda: self.app.comando_finito(comando, es["fascia"]))
        return es

    def apri(self, cosa):
        testo = str(cosa)
        if testo.startswith("http"):
            webbrowser.open(testo)
        else:
            os.startfile(testo)                      # noqa: S606 - file e cartelle dell'archivio, scelti dall'app

    def copia(self, testo):
        self._main(self.app.metti_negli_appunti, testo)

    def esito_risposta(self, testo, tipo="info"):
        self.app.coda.put(lambda: self.app.esito_risposta(testo, tipo))

    def mostra(self, testo, tipo="info"):
        self.app.coda.put(lambda: self.app.mostra(testo, tipo))

    def conferma(self, domanda):
        return self._main(self.app.domanda, domanda)

    def chiedi(self, titolo, campi):
        return self._main(self.app.modulo, titolo, campi)

    def modifica_temi(self, titolo, temi, risposte):
        return self._main(self.app.finestra_temi, titolo, temi, risposte)

    def risposta(self, agente, istruzioni):
        attesa = threading.Event()
        self._main(self.app.aspetta_risposta, agente, istruzioni, attesa)
        attesa.wait()
        return self._main(self.app.prendi_risposta)

    def attendi_chiusura(self, file):
        file = Path(file)
        blocco = file.with_name("~$" + file.name)
        chiuso = threading.Event()
        self._main(self.app.aspetta_chiusura, file, chiuso)
        inizio = time.time()
        aperto = False
        while not chiuso.is_set():                   # prima si aspetta che Excel lo apra, poi che lo chiuda
            occupato = aperto_qui(file) or blocco.exists()
            if occupato:
                aperto = True
            elif aperto or time.time() - inizio > 120:
                break
            time.sleep(2)
        annullato = self._main(self.app.fine_attesa)
        if annullato:
            raise flussi.Annullato("attesa del registro annullata")


class App:
    def __init__(self, root):
        self.root = root
        self.coda = queue.Queue()
        self.conf = flussi.configurazione()
        self.amb = AmbienteTk(self)
        self.flussi = flussi.Flussi(self.amb, self.conf)
        self.ascolto = appunti.Ascolto() if appunti.disponibili() and self.conf.get("ascolta_appunti", True) else None
        self.in_corso = None
        self.nome_processo = "Processo"              # il pulsante premuto, scritto nella fascia e nel passo in corso
        self.comando = None                          # (comando, inizio) mentre il motore lavora
        self.orologio = None                         # aggiornamento del tempo trascorso (root.after)
        self.attesa = None                           # (agente, Event) mentre si aspetta una risposta
        self.testo_risposta = None
        root.title("NFR Horizon Scan")
        larghezza, altezza = root.winfo_screenwidth(), root.winfo_screenheight()
        root.geometry(f"{int(larghezza * 0.62)}x{int(altezza * 0.82)}+{int(larghezza * 0.05)}+{int(altezza * 0.04)}")
        root.minsize(int(larghezza * 0.45), int(altezza * 0.6))
        if altezza <= 1200:                              # 1920x1080 e simili: tutto lo schermo, anche con la scala al 150%
            root.state("zoomed")
        self.costruisci()
        self.aggiorna_stato()
        root.after(100, self.svuota_coda)
        root.after(500, self.guarda_appunti)
        root.after(AGGIORNA_MS, self.aggiorna_periodico)

    # ------------------------------------------------------------ finestra
    def costruisci(self):
        stile = ttk.Style()
        stile.configure("Grande.TButton", font=("Segoe UI", 12, "bold"), padding=8)
        stile.configure("TButton", font=("Segoe UI", 10), padding=4)
        alto = ttk.Frame(self.root, padding=10)
        alto.pack(fill="x")
        self.righe_stato = ttk.Label(alto, font=("Segoe UI", 11), justify="left")
        self.righe_stato.pack(anchor="w")
        self.prossimo = ttk.Button(alto, style="Grande.TButton",
                                   command=lambda: self.avvia(self.flussi.prossimo, "Prossimo passo"))
        self.prossimo.pack(fill="x", pady=(8, 4))

        processi = ttk.Frame(self.root, padding=(10, 0))
        processi.pack(fill="x")
        self.con_a5 = tk.BooleanVar(value=False)
        # AU8 (scelte dell'utente del 04/11/2026): riquadri per cadenza con il lavoro che produce proposte, in fondo un
        # riquadro unico "Approvazioni e report" i cui pulsanti dicono su quale periodo lavorano (aggiorna_stato). I nomi
        # sono quelli della tabella "I processi" della guida, da cui vengono suggerimenti e descrizioni.
        voci = [("Analizza le notizie (A3)", self.flussi.settimanale, "Ogni settimana"),
                ("Analizza il trimestre (A1)", lambda: self.flussi.trimestrale(self.con_a5.get()), "Ogni trimestre"),
                ("Ciclo straordinario (A8)", lambda: self.flussi.straordinario(self.con_a5.get()), "All'occorrenza"),
                ("Aggiungi un rischio (A8)", lambda: self.flussi.aggiungi_rischio(self.con_a5.get()), "All'occorrenza"),
                ("Parere su una notizia (A4)", self.flussi.parere_a4, "All'occorrenza"),
                ("Apri chat (A7)", self.flussi.assistente_a7, "All'occorrenza"),
                ("Riapri un ciclo validato", self.flussi.riapertura, "All'occorrenza"),
                ("Rimuovi rischio", self.flussi.dismetti, "All'occorrenza"),
                ("Approva", self.flussi.approva, "Approvazioni e report"),
                ("Prepara le schede (A6)", self.flussi.schede, "Approvazioni e report"),
                ("Genera report", self.flussi.report, "Approvazioni e report"),
                ("Report mensile notizie", self.flussi.mensile, "Approvazioni e report")]
        self.pulsanti = [self.prossimo]
        self.per_nome = {}
        guida_pulsanti = aiuto.pulsanti()             # dalla tabella "I processi" della guida
        self.guida_pulsanti = guida_pulsanti
        parti = aiuto.parti_finestra()
        Suggerimento(self.prossimo, parti.get("▶ Prossimo passo", ""))
        riquadri = {}
        for n, (titolo, riga, colonna, largo) in enumerate((("Ogni settimana", 0, 0, 1), ("Ogni trimestre", 0, 1, 1),
                                                           ("All'occorrenza", 1, 0, 2), ("Approvazioni e report", 2, 0, 2))):
            r = ttk.LabelFrame(processi, text=titolo, padding=(6, 2))
            r.grid(row=riga, column=colonna, columnspan=largo, sticky="nsew", padx=2, pady=3)
            riquadri[titolo] = r
        for c in range(2):
            processi.columnconfigure(c, weight=1)
        conta = {}
        for testo, azione, riquadro in voci:
            k = conta[riquadro] = conta.get(riquadro, -1) + 1
            per_riga = 2 if riquadro == "Approvazioni e report" else 3
            b = ttk.Button(riquadri[riquadro], text=testo, command=lambda a=azione, n=testo: self.avvia(a, n))
            b.grid(row=k // per_riga, column=k % per_riga, sticky="ew", padx=2, pady=2)
            riquadri[riquadro].columnconfigure(k % per_riga, weight=1)
            Suggerimento(b, aiuto.suggerimento(testo, voci=guida_pulsanti))
            b.bind("<Enter>", lambda ev, n=testo: self.descrivi(n), add="+")
            b.bind("<Leave>", lambda ev: self.descrivi(None), add="+")
            self.pulsanti.append(b)
            self.per_nome[testo] = b
        casella_a5 = ttk.Checkbutton(riquadri["Ogni trimestre"], text="Con A5 Challenger (facoltativo)", variable=self.con_a5)
        casella_a5.grid(row=0, column=1, sticky="w", padx=6)
        self.etichette_dinamiche = {}
        self.descrizione = ttk.Label(processi, text=RIGA_DESCRIZIONE, foreground="#595959", wraplength=1500, justify="left")
        self.descrizione.grid(row=3, column=0, columnspan=2, sticky="w", padx=4, pady=(2, 4))
        opzioni = ttk.Frame(processi)
        opzioni.grid(row=4, column=0, columnspan=2, sticky="w", pady=(4, 0))
        Suggerimento(casella_a5, parti.get("Con A5 Challenger", ""))
        ttk.Label(opzioni, text="Agenti:").pack(side="left")
        self.origine = tk.StringVar(value=self.flussi.origine)
        scelta = ttk.Combobox(opzioni, textvariable=self.origine, values=list(flussi.ingresso.ORIGINI), state="readonly", width=16)
        scelta.pack(side="left")
        Suggerimento(scelta, parti.get("Agenti", ""))
        scelta.bind("<<ComboboxSelected>>", lambda ev: setattr(self.flussi, "origine", self.origine.get()))
        altro = ttk.Menubutton(opzioni, text="Altro")
        menu = tk.Menu(altro, tearoff=False)
        menu.add_command(label="Apri il registro (sola consultazione)", command=lambda: self.amb.apri(self.conf["workbook"]))
        menu.add_command(label="Apri l'archivio", command=lambda: self.amb.apri(self.conf["cartella_uscita"]))
        menu.add_command(label="Aggiorna lo stato", command=self.aggiorna_stato)
        menu.add_command(label="Verifica del PC", command=lambda: self.avvia(self.flussi.verifica_pc, "Verifica del PC"))
        menu.add_command(label="Temi da verificare (per A1)",
                         command=lambda: self.avvia(self.flussi.temi_da_verificare, "Temi da verificare"))
        menu.add_separator()
        menu.add_command(label="Togli il lucchetto rimasto (sblocca)", command=lambda: self.avvia(self.flussi.sblocca, "Sblocca"))
        menu.add_command(label="Ricostruisci la griglia di validazione",
                         command=lambda: self.avvia(lambda: self.flussi.motore("griglia"), "Griglia di validazione"))
        altro["menu"] = menu
        altro.pack(side="left", padx=12)
        Suggerimento(altro, parti.get("Altro", ""))
        b_admin = ttk.Button(opzioni, text="Admin...", command=self.apri_admin)     # D-85
        b_admin.pack(side="left", padx=(0, 12))
        Suggerimento(b_admin, parti.get("Admin...", ""))
        b_aiuto = ttk.Button(opzioni, text="Aiuto (F1)", command=self.apri_aiuto)
        b_aiuto.pack(side="left")
        Suggerimento(b_aiuto, "La guida dell'app e dei processi principali, presa da 00_GUIDA_PASSO_PASSO.md.")
        self.root.bind("<F1>", lambda ev: self.apri_aiuto())

        # Passo in corso e uscita del motore divisi da un divisore trascinabile (richiesta dell'utente del 23/10).
        divisore = ttk.PanedWindow(self.root, orient="vertical")
        divisore.pack(fill="both", expand=True, padx=10, pady=(8, 10))
        self.passo = ttk.LabelFrame(divisore, text="Passo in corso", padding=8)
        self.istruzioni = ttk.Label(self.passo, text=NESSUN_PROCESSO, justify="left", font=("Segoe UI", 10))
        self.istruzioni.pack(anchor="w", fill="x")
        self.passo.bind("<Configure>", lambda ev: self.istruzioni.config(wraplength=max(300, ev.width - 30)))
        bottoni = ttk.Frame(self.passo)
        bottoni.pack(side="bottom", anchor="w", pady=(6, 0))
        self.esito_incolla = tk.Label(self.passo, text="", font=("Segoe UI", 10, "bold"), anchor="w", justify="left")
        self.esito_incolla.pack(side="bottom", fill="x", pady=(4, 0))
        ttk.Label(self.passo, text="Risposta dell'agente: copiala dalla chat e incollala qui (Ctrl+V)").pack(anchor="w", pady=(6, 0))
        self.incolla = scrolledtext.ScrolledText(self.passo, height=10, font=("Consolas", 9), wrap="char")
        self.incolla.pack(fill="both", expand=True, pady=(2, 0))
        self.incolla.bind("<<Paste>>", self.prima_di_incollare)
        self.consegnato = False                      # il testo nel riquadro e' gia' stato consegnato al processo
        self.b_usa = ttk.Button(bottoni, text="Usa il testo incollato", command=self.usa_incollato)
        self.b_appunti = ttk.Button(bottoni, text="Leggi gli appunti adesso", command=self.leggi_appunti_adesso)
        self.b_file = ttk.Button(bottoni, text="Scegli file...", command=self.scegli_file)
        self.b_chiuso = ttk.Button(bottoni, text="Ho chiuso Excel: controlla ora", command=self.chiuso_a_mano)
        self.b_annulla = ttk.Button(bottoni, text="Annulla il passo", command=self.annulla)
        for b in (self.b_usa, self.b_appunti, self.b_file, self.b_chiuso, self.b_annulla):
            b.pack(side="left", padx=(0, 6))
        self.mostra_bottoni()

        uscita = ttk.Frame(divisore)
        self.fascia = tk.Label(uscita, text="", font=("Segoe UI", 11, "bold"), fg="white", bg="#FFFFFF", anchor="w", padx=10)
        self.fascia.pack(fill="x")
        self.log = scrolledtext.ScrolledText(uscita, font=("Consolas", 9), height=8, wrap="word")
        self.log.pack(fill="both", expand=True, pady=(4, 0))
        divisore.add(self.passo, weight=2)
        divisore.add(uscita, weight=3)
        self.root.after(300, lambda: divisore.sashpos(0, int(divisore.winfo_height() * 0.6)))
        self.log.tag_configure("comando", foreground="#1F3864", font=("Consolas", 9, "bold"))
        for tipo, colore in COLORI.items():
            self.log.tag_configure(tipo, foreground=colore, font=("Segoe UI", 10, "bold"))
        if not self.ascolto and self.conf.get("ascolta_appunti", True):
            self.mostra("Ascolto degli appunti non disponibile su questo PC (pywin32 mancante): incollare le risposte nel "
                        "riquadro, o sceglierle come file.", "avviso")

    def mostra_bottoni(self, risposta=False, chiusura=False):
        for b, visibile in ((self.b_usa, risposta), (self.b_appunti, risposta and self.ascolto), (self.b_file, risposta),
                            (self.b_chiuso, chiusura), (self.b_annulla, risposta or chiusura)):
            b.state(["!disabled"] if visibile else ["disabled"])

    # ------------------------------------------------------------ stato
    def aggiorna_stato(self):
        try:
            s = stato.leggi(self.conf)
        except Exception as ex:                      # noqa: BLE001 - lo stato non deve chiudere la finestra
            self.righe_stato.config(text=f"Stato non leggibile: {ex}")
            return
        r = s["righe"]                               # due righe: lo spazio va al passo in corso e all'uscita
        self.righe_stato.config(text="   ·   ".join(r[:2]) + "\n" + "   ·   ".join(r[2:]))
        p = s["prossimo"]
        self.prossimo.config(text=f"▶  Prossimo passo: {p['titolo']}\n{p['chi']}: {p['perche']}")
        self.etichette_dinamiche = etichette_uscite(s, self.flussi.da_approvare())
        for nome, testo in self.etichette_dinamiche.items():
            if nome in self.per_nome:
                self.per_nome[nome].config(text=testo)

    def descrivi(self, nome):
        """AU8: la riga sotto i riquadri dice che cosa fa il pulsante su cui passa il mouse (dalla guida)."""
        if not nome:
            self.descrizione.config(text=RIGA_DESCRIZIONE)
            return
        testo = self.etichette_dinamiche.get(nome, nome)
        app = (self.guida_pulsanti.get(nome) or ("",))[0]
        app = app.split(". ")[0].rstrip(".")                # la prima frase; la riga intera e' nella finestrella
        if len(app) > 230:
            app = app[:230].rsplit(";", 1)[0] + "..."
        self.descrizione.config(text=f"ⓘ {testo}: {app}." if app else f"ⓘ {testo}")

    def aggiorna_periodico(self):
        if not self.in_corso:
            self.aggiorna_stato()
        self.root.after(AGGIORNA_MS, self.aggiorna_periodico)

    # ------------------------------------------------------------ processi
    def avvia(self, azione, nome="Processo"):
        if self.in_corso:
            messagebox.showinfo("NFR Horizon Scan", f"C'e' gia' un processo in corso ({self.nome_processo}): finiscilo o "
                                "annullalo.", parent=self.root)
            return
        for b in self.pulsanti:
            b.state(["disabled"])
        self.nome_processo, self.comando = nome, None
        self.istruzioni.config(text=f"Processo \"{nome}\" avviato.")
        self.fase("avviato")

        def lavoro():
            try:
                azione()
            except flussi.Annullato as ex:
                self.amb.mostra(f"Processo interrotto ({ex}): si riprende dal passo giusto con il pulsante del prossimo passo.",
                                "avviso")
            except Exception as ex:                  # noqa: BLE001 - mostrato, mai una finestra che si chiude
                self.amb.mostra(f"Errore dell'app: {type(ex).__name__}: {ex}", "errore")
            finally:
                self.coda.put(self.fine_processo)
        self.in_corso = threading.Thread(target=lavoro, daemon=True)
        self.in_corso.start()

    def fine_processo(self):
        self.in_corso = None
        self.attesa = None
        self.comando = None
        for b in self.pulsanti:
            b.state(["!disabled"])
        self.istruzioni.config(text=f"Nessun processo in corso. L'ultimo, \"{self.nome_processo}\", e' finito alle "
                                    f"{time.strftime('%H:%M')}: l'esito e' nella fascia e nell'uscita qui sotto.")
        if self.fascia.cget("text").startswith("  In corso:"):     # nessun esito colorato dopo l'ultima fase
            self.fascia.config(text=f"  {self.nome_processo}: finito alle {time.strftime('%H:%M')}", bg=COLORI["info"])
        self.mostra_bottoni()
        self.aggiorna_stato()

    def svuota_coda(self):
        try:
            while True:
                self.coda.get_nowait()()
        except queue.Empty:
            pass
        self.root.after(100, self.svuota_coda)

    # ------------------------------------------------------------ che cosa sta facendo l'app
    def fase(self, testo):
        """La fascia dice sempre quale processo e' in corso e in che fase (richiesta dell'utente del 29/10)."""
        self.fascia.config(text=f"  In corso: {self.nome_processo} - {testo}"[:170], bg=COLORI["info"])

    def comando_iniziato(self, comando, riga):
        self.scrivi_log(f"\n> {riga}", "comando")
        self.comando = (comando, time.time())
        self.fase(f"comando {comando} in esecuzione")
        if self.orologio:
            self.root.after_cancel(self.orologio)
        self.tempo_comando()

    def tempo_comando(self):
        self.orologio = None
        if not self.comando:
            return
        comando, inizio = self.comando
        secondi = int(time.time() - inizio)
        self.istruzioni.config(text=f"Esecuzione del comando {comando} in corso da {secondi // 60}:{secondi % 60:02d} "
                                    f"({DURATA.get(comando, DURATA_EXCEL)}).\nNon serve fare niente: l'uscita del comando "
                                    "compare riga per riga qui sotto; alla fine il processo prosegue da solo.")
        self.orologio = self.root.after(1000, self.tempo_comando)

    def comando_finito(self, comando, fascia):
        self.comando = None
        self.istruzioni.config(text=f"Comando {comando} finito: {fascia}. Il processo \"{self.nome_processo}\" continua.")

    def in_primo_piano(self):
        """Porta la finestra davanti al browser e a Excel: una domanda dietro un'altra finestra sembrava un'app bloccata."""
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.attributes("-topmost", True)
            self.root.after(500, lambda: self.root.attributes("-topmost", False))
            self.root.focus_force()
            self.root.bell()
        except tk.TclError:
            pass

    def domanda(self, testo):
        self.istruzioni.config(text=f"In attesa della tua risposta alla domanda (finestra \"NFR Horizon Scan\", Si'/No):\n{testo}")
        self.fase("in attesa di una tua risposta (Si'/No)")
        self.in_primo_piano()
        risposta = messagebox.askyesno("NFR Horizon Scan", testo, parent=self.root)
        self.istruzioni.config(text=f"Risposta: {'Si' if risposta else 'No'}. Il processo continua.")
        self.fase("prosegue")
        return risposta

    # ------------------------------------------------------------ modalita' Admin (D-85)
    def apri_admin(self):
        """Il pulsante Admin: dopo una conferma (che lascia la traccia) apre la finestra delle funzioni amministrative,
        una per operazione con la spiegazione della guida (tabella "Pulsante Admin") e il suo pulsante. Finche' la
        finestra e' aperta l'app e' in modalita' Admin; chiuderla la spegne (anche questo resta nella traccia)."""
        if getattr(self, "finestra_admin", None) and self.finestra_admin.winfo_exists():
            self.finestra_admin.lift()
            return
        if not messagebox.askyesno(
                "NFR Horizon Scan - modalita' Admin",
                "La finestra Admin contiene le funzioni amministrative: nuovo registro, pulizia dell'archivio, ritorno a "
                "un ciclo validato, annullamento, ripartenza da zero, parcheggi, svuotamento.\n\nNiente si cancella "
                "subito (tutto va nel parcheggio con l'atto), ma ritorno e ripartenza cambiano la storia del registro: si "
                "fanno solo su decisione della funzione di rischio.\n\nAprire la finestra Admin? Resta traccia di chi "
                "l'ha aperta e quando.", parent=self.root):
            return
        self._admin(True)
        f = self.finestra_admin = tk.Toplevel(self.root)
        f.title("NFR Horizon Scan - Admin")
        f.protocol("WM_DELETE_WINDOW", self.chiudi_admin)
        corpo = ttk.Frame(f, padding=12)
        corpo.pack(fill="both", expand=True)
        ttk.Label(corpo, text="Funzioni amministrative (modalita' Admin)", font=("Segoe UI", 13, "bold")).grid(
            row=0, column=0, columnspan=2, sticky="w")
        ttk.Label(corpo, text="Niente si cancella subito, tranne con Svuota: cio' che un'operazione toglie va nel parcheggio "
                              "con l'atto e si puo' annullare. L'esito di ogni operazione e' nell'uscita della finestra "
                              "principale.", wraplength=760, justify="left").grid(row=1, column=0, columnspan=2, sticky="w",
                                                                                   pady=(4, 10))
        spiegazioni = aiuto.operazioni_admin()
        for n, op in enumerate(flussi.OPERAZIONI_ADMIN, start=2):
            serve, chiede = spiegazioni.get(op, ("", ""))
            ttk.Button(corpo, text=op, width=18,
                       command=lambda o=op: self.avvia(lambda: self.flussi.amministrazione(o), f"Admin: {o}")).grid(
                row=n, column=0, sticky="nw", pady=4, padx=(0, 12))
            ttk.Label(corpo, text=f"{serve}\nChiede: {chiede}" if chiede else serve, wraplength=600, justify="left").grid(
                row=n, column=1, sticky="w", pady=4)
        sotto = ttk.Frame(corpo)
        sotto.grid(row=len(flussi.OPERAZIONI_ADMIN) + 2, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        ttk.Button(sotto, text="Aiuto: Pulsante Admin", command=lambda: self.apri_aiuto("Pulsante Admin")).pack(side="left")
        ttk.Button(sotto, text="Chiudi (spegne la modalita' Admin)", command=self.chiudi_admin).pack(side="right")

    def chiudi_admin(self):
        if getattr(self, "finestra_admin", None) and self.finestra_admin.winfo_exists():
            self.finestra_admin.destroy()
        self.finestra_admin = None
        self._admin(False)

    def _admin(self, attiva):
        self.flussi.admin = attiva
        self.root.title("NFR Horizon Scan" + ("  —  ADMIN" if attiva else ""))
        try:
            amministrazione.segna_admin(self.conf, self.conf, attiva)
        except Exception as ex:                      # noqa: BLE001 - la traccia non deve impedire di lavorare
            self.scrivi_log(f"(traccia della modalita' Admin non scritta: {ex})", "avviso")
        self.mostra("Modalita' Admin: finestra Admin aperta." if attiva else "Modalita' Admin spenta.",
                    "avviso" if attiva else "info")

    # ------------------------------------------------------------ aiuto (dalla guida)
    def apri_aiuto(self, argomento=0):
        """Una finestra con gli argomenti della guida (aiuto.ARGOMENTI) a sinistra e il testo a destra. Il testo e'
        quello di 00_GUIDA_PASSO_PASSO.md, letto ogni volta: nessuna copia da tenere allineata."""
        voci = aiuto.argomenti()
        if isinstance(argomento, str):               # per titolo (per esempio "Pulsante Admin")
            argomento = next((k for k, (titolo, _) in enumerate(voci) if titolo == argomento), 0)
        if getattr(self, "finestra_aiuto", None) and self.finestra_aiuto.winfo_exists():
            self.finestra_aiuto.destroy()
        f = self.finestra_aiuto = tk.Toplevel(self.root)
        f.title("NFR Horizon Scan - Aiuto")
        f.geometry(f"{int(self.root.winfo_screenwidth() * 0.55)}x{int(self.root.winfo_screenheight() * 0.75)}")
        if not voci:
            ttk.Label(f, text=f"Guida non trovata: {aiuto.GUIDA}", padding=12).pack()
            return
        corpo = ttk.PanedWindow(f, orient="horizontal")
        corpo.pack(fill="both", expand=True, padx=8, pady=8)
        elenco = tk.Listbox(corpo, font=("Segoe UI", 10), activestyle="none", exportselection=False, width=34)
        for titolo, _ in voci:
            elenco.insert("end", titolo)
        testo = scrolledtext.ScrolledText(corpo, wrap="word", font=STILI_AIUTO["testo"], padx=12, pady=8)
        for stile, carattere in STILI_AIUTO.items():
            rientro = 24 if stile in ("voce", "elenco") else 0
            testo.tag_configure(stile, font=carattere, spacing1=6 if stile in ("titolo", "sottotitolo") else 1,
                                lmargin2=rientro)
            testo.tag_configure(stile + "_g", font=(carattere[0], carattere[1], "bold"), lmargin2=rientro)
        corpo.add(elenco, weight=1)
        corpo.add(testo, weight=4)

        def mostra(_=None):
            scelti = elenco.curselection()
            if not scelti:
                return
            testo.config(state="normal")
            testo.delete("1.0", "end")
            for stile, pezzi in aiuto.righe(voci[scelti[0]][1]):
                for pezzo, grassetto in pezzi:
                    testo.insert("end", pezzo, stile + ("_g" if grassetto else ""))
                testo.insert("end", "\n")
            testo.config(state="disabled")
            testo.yview_moveto(0)
        elenco.bind("<<ListboxSelect>>", mostra)
        elenco.selection_set(argomento)
        mostra()
        sotto = ttk.Frame(f, padding=(8, 0, 8, 8))
        sotto.pack(fill="x")
        ttk.Label(sotto, text=f"Dalla guida: {aiuto.GUIDA.name}", foreground="#555555").pack(side="left")
        ttk.Button(sotto, text="Chiudi", command=f.destroy).pack(side="right")
        ttk.Button(sotto, text="Apri la guida completa", command=lambda: self.amb.apri(aiuto.GUIDA)).pack(side="right", padx=6)

    # ------------------------------------------------------------ messaggi
    def scrivi_log(self, testo, tag=None):
        self.log.insert("end", testo + "\n", tag or ())
        self.log.see("end")

    def mostra(self, testo, tipo="info"):
        self.scrivi_log(testo, tipo)
        if tipo in ("ok", "avviso", "errore"):
            self.fascia.config(text="  " + testo.splitlines()[0][:160], bg=COLORI[tipo])

    def metti_negli_appunti(self, testo):
        if self.ascolto:
            self.ascolto.scritta_da_me(appunti.scrivi(testo))
        else:
            self.root.clipboard_clear()
            self.root.clipboard_append(testo)
        self.scrivi_log("(negli appunti: " + testo.splitlines()[0][:100] + ("..." if len(testo) > 100 else "") + ")", "info")

    def modulo(self, titolo, campi):
        self.istruzioni.config(text=f"In attesa che tu compili il modulo \"{titolo}\" (Conferma o Annulla).")
        self.fase("in attesa del modulo")
        self.in_primo_piano()
        finestra = tk.Toplevel(self.root)
        finestra.title(titolo)
        finestra.transient(self.root)
        finestra.grab_set()
        finestra.lift()
        finestra.focus_force()
        valori, esito = {}, {}
        ttk.Label(finestra, text=titolo, font=("Segoe UI", 11, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", padx=10, pady=8)
        for i, campo in enumerate(campi, start=1):
            chiave, etichetta, predefinito = campo[:3]
            scelte = campo[3] if len(campo) > 3 else None
            ttk.Label(finestra, text=etichetta, wraplength=380).grid(row=i, column=0, sticky="w", padx=10, pady=3)
            v = tk.StringVar(value=predefinito)
            if scelte:                               # elenco a discesa; con solo_scelte non si scrive altro
                ttk.Combobox(finestra, textvariable=v, values=list(scelte), width=58,
                             state="readonly" if len(campo) > 4 and campo[4] else "normal").grid(row=i, column=1, padx=10, pady=3)
            else:
                ttk.Entry(finestra, textvariable=v, width=60).grid(row=i, column=1, padx=10, pady=3)
            valori[chiave] = v

        def ok():
            esito["v"] = {k: v.get().strip() for k, v in valori.items()}
            finestra.destroy()
        riga = len(campi) + 1
        ttk.Button(finestra, text="Conferma", command=ok).grid(row=riga, column=1, sticky="e", padx=10, pady=10)
        ttk.Button(finestra, text="Annulla", command=finestra.destroy).grid(row=riga, column=0, sticky="w", padx=10, pady=10)
        self.root.wait_window(finestra)
        return esito.get("v")

    def finestra_temi(self, titolo, temi, risposte):
        """P9 (D-98): la tabella dei temi da verificare con l'ultima risposta di A1; sotto, il tema scelto da modificare.
        Conferma restituisce la lista (anche invariata), Annulla None."""
        self.istruzioni.config(text=f"In attesa che tu riveda i temi da verificare (\"{titolo}\": Conferma o Annulla).")
        self.fase("in attesa dei temi da verificare")
        self.in_primo_piano()
        finestra = tk.Toplevel(self.root)
        finestra.title("Temi da verificare")
        finestra.transient(self.root)
        finestra.grab_set()
        finestra.lift()
        finestra.focus_force()
        elenco, esito = [dict(t) for t in temi], {}
        ttk.Label(finestra, text=titolo, font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=10, pady=(8, 2))
        ttk.Label(finestra, wraplength=900, justify="left",
                  text="I temi aperti arrivano ad A1 nella baseline del prossimo ciclo trimestrale: per ognuno A1 risponde con "
                       "un rischio (nel radar o in osservazione) o fra i fenomeni non censiti, con il motivo. Chiudi un tema "
                       "quando la risposta basta; resta nel file come traccia.").pack(anchor="w", padx=10)
        colonne = ("codice", "tema", "chiesto_da", "stato", "risposta")
        albero = ttk.Treeview(finestra, columns=colonne, show="headings", height=10, selectmode="browse")
        for c, testo, largo in zip(colonne, ("Codice", "Tema", "Chiesto da", "Stato", "Ultima risposta di A1"),
                                   (80, 380, 140, 70, 260)):
            albero.heading(c, text=testo)
            albero.column(c, width=largo, stretch=c in ("tema", "risposta"))
        albero.pack(fill="both", expand=True, padx=10, pady=6)
        modulo = ttk.Frame(finestra)
        modulo.pack(fill="x", padx=10)
        campi = {}
        for i, (chiave, etichetta) in enumerate((("tema", "Tema (che cosa verificare)"), ("chiesto_da", "Chiesto da"),
                                                 ("perche", "Perche'"))):
            ttk.Label(modulo, text=etichetta).grid(row=i, column=0, sticky="w", pady=2)
            campi[chiave] = tk.StringVar()
            ttk.Entry(modulo, textvariable=campi[chiave], width=100).grid(row=i, column=1, sticky="ew", pady=2)
        campi["stato"] = tk.StringVar(value="aperto")
        ttk.Label(modulo, text="Stato").grid(row=3, column=0, sticky="w", pady=2)
        ttk.Combobox(modulo, textvariable=campi["stato"], values=("aperto", "chiuso"), state="readonly",
                     width=10).grid(row=3, column=1, sticky="w", pady=2)
        modulo.columnconfigure(1, weight=1)

        def ridisegna(scelto=None):
            albero.delete(*albero.get_children())
            for i, t in enumerate(elenco):
                albero.insert("", "end", iid=str(i), values=(t.get("codice") or "(nuovo)", t.get("tema"), t.get("chiesto_da"),
                                                            t.get("stato") or "aperto", risposte.get(t.get("codice"), "—")))
            if scelto is not None and str(scelto) in albero.get_children():
                albero.selection_set(str(scelto))

        def scelto():
            sel = albero.selection()
            return int(sel[0]) if sel else None

        def carica(_=None):
            i = scelto()
            if i is not None:
                for k, v in campi.items():
                    v.set(elenco[i].get(k) or ("aperto" if k == "stato" else ""))

        def valori():
            return {k: v.get().strip() for k, v in campi.items()}

        def aggiungi():
            if not campi["tema"].get().strip():
                messagebox.showwarning("Temi da verificare", "Scrivi prima il tema.", parent=finestra)
                return
            elenco.append({"codice": "", "data": "", **valori()})
            ridisegna(len(elenco) - 1)

        def applica():
            i = scelto()
            if i is None:
                messagebox.showinfo("Temi da verificare", "Scegli prima un tema nella tabella.", parent=finestra)
                return
            elenco[i].update(valori())
            ridisegna(i)

        albero.bind("<<TreeviewSelect>>", carica)
        bottoni = ttk.Frame(finestra)
        bottoni.pack(fill="x", padx=10, pady=8)
        ttk.Button(bottoni, text="Aggiungi come tema nuovo", command=aggiungi).pack(side="left")
        ttk.Button(bottoni, text="Modifica il tema scelto", command=applica).pack(side="left", padx=6)

        def conferma():
            esito["v"] = elenco
            finestra.destroy()
        ttk.Button(bottoni, text="Conferma", command=conferma).pack(side="right")
        ttk.Button(bottoni, text="Annulla", command=finestra.destroy).pack(side="right", padx=6)
        ridisegna()
        self.root.wait_window(finestra)
        return esito.get("v")

    # ------------------------------------------------------------ risposte degli agenti
    def aspetta_risposta(self, agente, istruzioni, evento):
        self.attesa = (agente, evento)
        self.testo_risposta = None
        if self.ascolto:
            self.ascolto.ricomincia()
        self.istruzioni.config(text=f"In attesa della risposta di {agente}.\n{istruzioni}")
        self.fase(f"in attesa della risposta di {agente}")
        self.mostra_bottoni(risposta=True)

    def consegna(self, testo):
        if not self.attesa:
            return
        agente, evento = self.attesa
        self.testo_risposta, self.attesa = testo, None
        self.mostra_bottoni()
        if testo is not None:
            if self.incolla.get("1.0", "end").strip() != testo.strip():      # dagli appunti o da un file: si vede
                self.incolla.delete("1.0", "end")
                self.incolla.insert("1.0", testo)
            self.consegnato = True
            self.esito_risposta(f"Risposta di {agente} in lettura: {len(testo):,} caratteri...".replace(",", "."), "info")
            self.scrivi_log(f"(risposta di {agente} ricevuta: {len(testo)} caratteri)", "info")
        evento.set()

    def esito_risposta(self, testo, tipo="info"):
        """La riga sotto il riquadro: che cosa e' stato riconosciuto e salvato (o perche' no)."""
        self.esito_incolla.config(text=testo, fg=COLORI.get(tipo, COLORI["info"]))

    def prima_di_incollare(self, evento):
        """Ctrl+V nel riquadro: se c'e' il testo di una risposta gia' consegnata si toglie, cosi' la nuova lo sostituisce;
        poi, a incolla finita, la risposta passa al processo."""
        if self.consegnato:
            self.incolla.delete("1.0", "end")
            self.consegnato = False
        self.root.after(150, self.usa_incollato)

    def prendi_risposta(self):
        return self.testo_risposta

    def guarda_appunti(self):
        if self.attesa and self.ascolto:
            testo = self.ascolto.nuova()
            if testo and ("{" in testo or self.attesa[0] == "A4"):
                self.consegna(testo)
        self.root.after(500, self.guarda_appunti)

    def usa_incollato(self):
        """La risposta incollata nel riquadro: si consegna al processo che la aspetta, e il riquadro si svuota."""
        testo = self.incolla.get("1.0", "end").strip()
        if not self.attesa or not testo:
            return
        if "{" not in testo and self.attesa[0] != "A4":
            self.esito_risposta("Il testo incollato non contiene un JSON: copia la risposta intera (pulsante Copia sotto la "
                                "risposta).", "avviso")
            return                                   # incollato a meta' o testo sbagliato: si aspetta il pulsante
        self.consegna(testo)

    def leggi_appunti_adesso(self):
        if self.attesa and self.ascolto:
            testo = appunti.leggi()
            if testo:
                self.consegna(testo)

    def scegli_file(self):
        if not self.attesa:
            return
        nome = filedialog.askopenfilename(parent=self.root, title=f"Risposta di {self.attesa[0]}",
                                          filetypes=[("Risposte", "*.json *.txt"), ("Tutti i file", "*.*")])
        if nome:
            self.consegna(Path(nome).read_text(encoding="utf-8-sig", errors="replace"))

    def annulla(self):
        if self.attesa:
            self.consegna(None)
        elif getattr(self, "chiusura", None):
            self.chiusura_annullata = True
            self.chiusura.set()

    # ------------------------------------------------------------ registro aperto in Excel
    def aspetta_chiusura(self, file, evento):
        self.chiusura, self.chiusura_annullata, self.file_chiusura = evento, False, Path(file)
        self.istruzioni.config(text=f"In attesa che tu chiuda il registro in Excel ({Path(file).name}). Lavora nelle celle "
                                    "gialle, salva e chiudi Excel: l'app se ne accorge da sola entro pochi secondi e poi "
                                    "lancia il comando.\nSe l'hai gia' chiuso e l'app e' ancora qui, premi \"Ho chiuso Excel: "
                                    "controlla ora\".")
        self.fase(f"in attesa che tu chiuda Excel ({Path(file).name})")
        self.esito_risposta("")
        self.mostra_bottoni(chiusura=True)

    def chiuso_a_mano(self):
        """Il pulsante controlla davvero: con il registro ancora aperto da Excel su questo PC il comando si fermerebbe."""
        if not getattr(self, "chiusura", None):
            return
        if aperto_qui(self.file_chiusura):
            self.esito_risposta(f"{self.file_chiusura.name} risulta ancora aperto in Excel su questo PC: salvalo, chiudi "
                                "Excel (guarda anche nella barra delle applicazioni) e premi di nuovo.", "avviso")
            return
        self.esito_risposta("Registro chiuso: si prosegue.", "ok")
        self.chiusura.set()

    def fine_attesa(self):
        self.chiusura = None
        self.istruzioni.config(text="Registro chiuso: il processo continua.")
        self.mostra_bottoni()
        return getattr(self, "chiusura_annullata", False)


def nitido():
    """Testi nitidi sugli schermi con la scala di Windows oltre il 100% (altrimenti la finestra e' sfocata)."""
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:                                # noqa: BLE001 - Windows vecchio o non Windows: si vede lo stesso
        pass


def main():
    nitido()
    root = tk.Tk()
    try:
        App(root)
    except Exception as ex:                          # noqa: BLE001 - configurazione mancante o illeggibile
        messagebox.showerror("NFR Horizon Scan", f"L'app non parte: {type(ex).__name__}: {ex}\n\nControllare "
                             "configurazione.json accanto agli script (guida, sezione 0.3).")
        root.destroy()
        return
    root.mainloop()


if __name__ == "__main__":
    main()
